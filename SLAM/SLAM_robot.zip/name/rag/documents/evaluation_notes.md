# Evaluation Notes
Retrieval quality and generation quality should be evaluated separately. Retrieval can be measured with Recall@K by checking whether the expected source appears in the top retrieved chunks. Generation can be reviewed qualitatively for answer relevance, source correctness, and whether unsupported claims are avoided.

RAG failure modes include wrong chunks, missing information, ambiguous questions, hallucination, chunks that are too small, chunks that are too large, and too much irrelevant context.
