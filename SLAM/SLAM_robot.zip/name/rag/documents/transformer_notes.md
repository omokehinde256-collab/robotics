# Transformer Notes
A Transformer is a neural network architecture based on self-attention. Self-attention allows each token to compare itself with every other token in the sequence. Multi-head attention runs several attention operations in parallel so the model can learn different relationships between words.

Positional encoding gives the Transformer information about token order because self-attention does not naturally encode sequence position. Encoder-decoder Transformers are commonly used for translation, summarization, and question answering.
