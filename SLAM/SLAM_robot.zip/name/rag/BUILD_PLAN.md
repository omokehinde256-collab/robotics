# Build Plan: Retrieval-Augmented Generation Notebook

## Primary Deliverable

Create one Colab-ready Jupyter notebook:

```text
new/003/rag_system.ipynb
```

The notebook will build a complete Retrieval-Augmented Generation system using open Hugging Face models only. It will not use OpenAI, Gemini, Claude, or any hosted answering API.

## Core Approach

The notebook will expose the RAG pipeline stage by stage:

```text
Documents -> extraction -> cleaning -> chunking -> embeddings -> FAISS index
Question -> query embedding -> retrieval -> prompt -> generator -> answer + sources
```

The implementation will use libraries for PDF extraction, sentence embeddings, FAISS, and Hugging Face generation, while implementing the educational RAG steps directly in notebook code.

## Model Choices

- Embeddings: `sentence-transformers/all-MiniLM-L6-v2`
- Generator: `google/flan-t5-base`

`all-MiniLM-L6-v2` is small and fast for semantic retrieval. `flan-t5-base` is instruction-tuned, non-commercial-API based, and realistic for a standard Colab runtime. The code will use GPU when available and CPU fallbacks otherwise.

## Notebook Sections

Planned numbered sections:

1. Introduction
2. What is Retrieval-Augmented Generation?
3. RAG Architecture
4. Environment Setup
5. Configuration
6. Runtime and Device Information
7. Document Input Options
8. Loading Documents
9. Extracting PDF Text
10. TXT and Markdown Loading
11. Text Cleaning
12. Chunking Documents
13. Chunk Metadata
14. Displaying Sample Chunks
15. Understanding Embeddings
16. Loading the Embedding Model
17. Generating Document Embeddings
18. Cosine Similarity
19. Building the FAISS Index
20. Retrieval Without Generation
21. Retrieval Function
22. Saving the Knowledge Base
23. Loading the Knowledge Base
24. Optional Google Drive Persistence
25. Loading the Generator Model
26. Retriever vs Generator
27. Prompt Construction
28. Context Length Control
29. Generating Grounded Answers
30. Complete RAG Function
31. Source Citations
32. Source Deduplication
33. Showing Retrieval Evidence
34. Unknown Questions
35. Retrieval Threshold
36. RAG vs Normal LLM
37. Multiple Questions
38. Multiple Document Retrieval
39. Retrieval Evaluation
40. Basic RAG Evaluation
41. RAG Failure Modes
42. Chunk-Size Experiment
43. Top-K Experiment
44. Interactive Notebook Demo
45. Optional Gradio Interface
46. Saving System Artifacts
47. Reload Without Re-Indexing
48. Optional Offline Artifact Mode
49. Model Memory Management
50. RAG vs Fine-Tuning
51. Difference from Extractive QA
52. Final Summary

## Implementation Requirements

- `REBUILD_INDEX = True` builds a new knowledge base.
- `REBUILD_INDEX = False` loads an existing FAISS index and chunk metadata without reprocessing documents.
- Support PDF, TXT, and Markdown files.
- Preserve source and page metadata.
- Use word-aware overlapping chunks.
- Store aligned chunk metadata with embeddings and FAISS vector IDs.
- Save:

```text
artifacts/
├── knowledge_base/
│   ├── faiss.index
│   ├── chunks.json
│   ├── metadata.json
│   └── embedding_config.json
├── config.json
├── evaluation_results.json
└── README.txt
```

## Verification Plan

Before handoff:

1. Validate notebook JSON.
2. Confirm the notebook contains all required sections.
3. Confirm dependency install commands are present.
4. Confirm document loaders support PDF, TXT, and Markdown.
5. Confirm chunking, metadata, embedding, FAISS, save, reload, retrieval, prompt, answer, and citation functions are present.
6. Confirm `REBUILD_INDEX = False` does not rebuild embeddings.
7. Confirm no answers, sources, or evaluation numbers are hard-coded.
8. Run lightweight structural checks locally. Full sequential execution should be done in Colab because model downloads may be large.
