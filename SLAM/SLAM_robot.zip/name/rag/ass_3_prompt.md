# Retrieval-Augmented Generation (RAG) System in Jupyter / Google Colab

Build a complete **Retrieval-Augmented Generation (RAG) system** as a **Jupyter Notebook (`.ipynb`) designed to run in Google Colab**.

The project must be educational, well-commented, easy to follow, and suitable for a university assignment or project defense.

The system should allow a user to upload or provide documents such as:

* PDF files
* TXT files
* Markdown files
* Lecture notes
* Research papers
* Course materials

The system should then:

1. Extract the text.
2. Split the text into chunks.
3. Convert chunks into vector embeddings.
4. Store the embeddings in a FAISS vector index.
5. Accept a user question.
6. Convert the question into an embedding.
7. Retrieve the most relevant document chunks.
8. Construct a prompt containing the retrieved context.
9. Send that prompt to a Hugging Face language model.
10. Generate an answer grounded in the retrieved documents.
11. Display the sources used for the answer.

Do NOT rely on an external commercial API such as OpenAI, Gemini, Claude, or another hosted LLM API.

Use open Hugging Face models that can run in Google Colab.

---

# 1. PROJECT OBJECTIVE

The notebook should demonstrate the complete RAG pipeline:

```text
Documents
    ↓
Text Extraction
    ↓
Text Cleaning
    ↓
Chunking
    ↓
Embedding Model
    ↓
Vector Embeddings
    ↓
FAISS Vector Database
    ↓

User Question
    ↓
Question Embedding
    ↓
Similarity Search
    ↓
Top-K Relevant Chunks
    ↓
Prompt Construction
    ↓
Hugging Face Generator Model
    ↓
Grounded Answer
    ↓
Sources / Citations
```

The project must make the distinction between **retrieval** and **generation** clear.

---

# 2. RECOMMENDED TECHNOLOGY STACK

Use:

```python
transformers
sentence-transformers
faiss-cpu
torch
numpy
pandas
pypdf
```

and other lightweight packages only where needed.

Preferred embedding model:

```text
sentence-transformers/all-MiniLM-L6-v2
```

This model is small, fast, and suitable for semantic search.

For generation, choose a reasonably small instruction-following Hugging Face model that can run on a normal Google Colab GPU.

Prefer an instruction-tuned model rather than a plain language model.

Select a model that is realistically runnable in Colab.

Examples may include suitable small models from families such as:

```text
Qwen
Gemma
Phi
FLAN-T5
```

Choose the best currently practical model while keeping GPU memory usage reasonable.

Do not use a model so large that the notebook cannot realistically run in a standard Colab environment.

Explain why the selected generator model was chosen.

---

# 3. DO NOT HIDE THE RAG PIPELINE

Do NOT implement the entire project using a single high-level LangChain or LlamaIndex RAG class.

The educational objective is to show the actual stages.

It is acceptable to use libraries for:

```text
PDF extraction
Sentence embeddings
FAISS
Hugging Face generation
```

But explicitly implement:

```text
document loading
cleaning
chunking
metadata tracking
embedding
index construction
query embedding
similarity search
retrieval
prompt construction
generation
citation formatting
```

The notebook should make it obvious how RAG works internally.

---

# 4. NOTEBOOK STRUCTURE

Create:

```text
rag_system.ipynb
```

Organize it into numbered sections such as:

```text
1. Introduction
2. What is Retrieval-Augmented Generation?
3. RAG Architecture
4. Environment Setup
5. Configuration
6. Loading Documents
7. Extracting Text
8. Cleaning Text
9. Chunking Documents
10. Understanding Embeddings
11. Loading the Embedding Model
12. Generating Document Embeddings
13. Building the FAISS Index
14. Saving the Knowledge Base
15. Loading an Existing Knowledge Base
16. Query Embedding
17. Semantic Retrieval
18. Inspecting Retrieved Chunks
19. Loading the Generator Model
20. Prompt Construction
21. Generating a Grounded Answer
22. Adding Source Citations
23. Complete RAG Pipeline
24. Asking Multiple Questions
25. Handling Unknown Questions
26. Retrieval Evaluation
27. RAG Evaluation
28. Saving and Reloading the System
29. Interactive Demo
30. Optional Gradio Interface
31. Limitations
32. Conclusion
```

Each major section must contain explanatory Markdown before the code.

---

# 5. EXPLAIN WHAT RAG IS

Provide a concise explanation that a normal LLM answers using knowledge stored in its parameters, while a RAG system retrieves relevant external information before generation.

Show:

```text
Normal LLM:

Question
   ↓
LLM
   ↓
Answer
```

versus:

```text
RAG:

Question
   ↓
Retriever
   ↓
Relevant documents
   ↓
LLM + retrieved context
   ↓
Grounded answer
```

Explain that retrieval allows the system to answer questions about documents that the generator was never trained on.

---

# 6. CONFIGURATION CELL

Create one clear configuration cell.

For example:

```python
CONFIG = {
    "embedding_model": "sentence-transformers/all-MiniLM-L6-v2",

    "generator_model": "...",

    "chunk_size": 500,
    "chunk_overlap": 100,

    "top_k": 5,

    "max_new_tokens": 256,

    "temperature": 0.2,

    "knowledge_base_dir": "./artifacts/knowledge_base"
}
```

Also include:

```python
REBUILD_INDEX = True
```

When:

```python
REBUILD_INDEX = True
```

the notebook should process documents and build a new FAISS index.

When:

```python
REBUILD_INDEX = False
```

the notebook should load the previously saved index and metadata.

This is important so embeddings do not need to be regenerated every time.

---

# 7. GOOGLE COLAB SUPPORT

Detect whether GPU is available.

Display:

```text
PyTorch version
CUDA available
GPU model
```

Use GPU for the generator when available.

The sentence embedding model may use GPU where beneficial.

Use CPU-compatible fallbacks.

---

# 8. DOCUMENT INPUT

Support at least:

```text
PDF
TXT
Markdown
```

Allow a configurable document directory such as:

```text
/content/documents/
```

Add an optional Google Colab upload section:

```python
from google.colab import files
uploaded = files.upload()
```

but do not make uploads mandatory.

Also allow documents already stored in Google Drive.

---

# 9. PDF EXTRACTION

Use a reliable PDF library such as:

```python
pypdf
```

Create:

```python
def extract_text_from_pdf(path):
    ...
```

Preserve page metadata.

Each extracted page should retain information such as:

```python
{
    "source": "machine_learning_notes.pdf",
    "page": 12,
    "text": "..."
}
```

This metadata will later be used for citations.

Do not throw away page numbers.

---

# 10. TXT AND MARKDOWN SUPPORT

Create equivalent document loaders.

For example:

```python
load_txt(...)
load_markdown(...)
```

For files without page numbers, use metadata such as:

```python
{
    "source": "lecture_notes.txt",
    "page": None
}
```

---

# 11. TEXT CLEANING

Create a text cleaning function.

Handle:

```text
extra whitespace
repeated line breaks
broken spaces
Unicode normalization
```

Do not over-clean the text.

Do not remove useful punctuation or structure unnecessarily.

Show a sample before and after cleaning.

---

# 12. CHUNKING

Implement chunking explicitly.

Do not hide it behind a high-level framework.

Create something conceptually like:

```python
def chunk_text(
    text,
    chunk_size=500,
    overlap=100
):
    ...
```

Prefer token-aware or word-aware chunking rather than blindly splitting every N characters if practical.

Explain:

```text
chunk_size
```

and:

```text
chunk_overlap
```

For example:

```text
Chunk 1:
tokens 0–499

Chunk 2:
tokens 400–899

Chunk 3:
tokens 800–1299
```

Explain that overlap helps preserve information near chunk boundaries.

---

# 13. CHUNK METADATA

Every chunk must retain metadata.

For example:

```python
{
    "chunk_id": 37,
    "source": "transformer_notes.pdf",
    "page": 8,
    "text": "...",
}
```

If a chunk spans multiple pages, preserve appropriate page information where possible.

Metadata and embeddings must remain aligned.

---

# 14. DISPLAY CHUNKS

Show a few sample chunks.

Display:

```text
Chunk ID
Source
Page
Character/token length
Text preview
```

This makes the preprocessing stage easy to explain.

---

# 15. EMBEDDINGS EXPLANATION

Explain that an embedding maps text into a numerical vector:

```text
"The Transformer uses self-attention"

↓

[0.12, -0.37, 0.81, ...]
```

Semantically similar text should have vectors close to each other.

Explain why this allows semantic retrieval.

---

# 16. LOAD THE EMBEDDING MODEL

Use:

```python
from sentence_transformers import SentenceTransformer
```

Load:

```python
embedding_model = SentenceTransformer(
    "sentence-transformers/all-MiniLM-L6-v2"
)
```

Print the embedding dimensionality.

For MiniLM this is typically:

```text
384 dimensions
```

Verify rather than hard-code where possible.

---

# 17. GENERATE DOCUMENT EMBEDDINGS

Encode every chunk.

For example:

```python
embeddings = embedding_model.encode(
    chunk_texts,
    batch_size=...,
    show_progress_bar=True,
    normalize_embeddings=True
)
```

Explain the output shape:

```text
[number_of_chunks, embedding_dimension]
```

For example:

```text
[2400, 384]
```

---

# 18. COSINE SIMILARITY

Explain cosine similarity:

[
\cos(\theta)
============

\frac{A \cdot B}
{|A||B|}
]

Explain that if embeddings are normalized, inner product can be used to calculate cosine similarity efficiently.

---

# 19. BUILD THE FAISS INDEX

Use FAISS.

For normalized embeddings, consider:

```python
faiss.IndexFlatIP
```

Explain why inner product corresponds to cosine similarity when vectors are normalized.

Build:

```python
index.add(embeddings)
```

Print:

```text
Number of indexed chunks
Embedding dimension
```

---

# 20. RETRIEVAL WITHOUT GENERATION

Before introducing the LLM, demonstrate retrieval independently.

Example:

```python
question = "What is multi-head attention?"
```

Compute:

```text
question
   ↓
question embedding
   ↓
FAISS
   ↓
top 5 chunks
```

Display a table:

```text
Rank
Similarity Score
Source
Page
Chunk text
```

This section is very important because it demonstrates that retrieval works before adding generation.

---

# 21. RETRIEVAL FUNCTION

Create:

```python
def retrieve(
    question,
    top_k=5
):
    ...
```

Return structured results such as:

```python
[
    {
        "rank": 1,
        "score": 0.82,
        "source": "transformers.pdf",
        "page": 5,
        "chunk_id": 43,
        "text": "..."
    }
]
```

---

# 22. SAVE THE KNOWLEDGE BASE

Save:

```text
artifacts/
└── knowledge_base/
    ├── faiss.index
    ├── chunks.json
    ├── metadata.json
    └── embedding_config.json
```

Use:

```python
faiss.write_index(...)
```

The saved knowledge base should contain everything required to perform retrieval later without re-embedding documents.

---

# 23. LOAD THE KNOWLEDGE BASE

Implement:

```python
load_knowledge_base(...)
```

It should restore:

```text
FAISS index
chunks
metadata
embedding configuration
```

Verify that retrieval produces the same type of results after reloading.

---

# 24. GOOGLE DRIVE PERSISTENCE

Add optional Google Drive support:

```python
from google.colab import drive
drive.mount("/content/drive")
```

Allow artifact storage at:

```text
/content/drive/MyDrive/rag_project/
```

The notebook must still work without Drive.

---

# 25. GENERATOR MODEL

Load an instruction-following Hugging Face model using:

```python
AutoTokenizer
AutoModelForCausalLM
```

or, if an encoder-decoder generator is selected:

```python
AutoModelForSeq2SeqLM
```

Use:

```python
transformers.pipeline(...)
```

for generation if appropriate.

Select a model that can reasonably fit in Colab.

If useful, use:

```text
float16
bfloat16
```

or quantization when supported.

Keep the code understandable.

---

# 26. GENERATOR MODEL EXPLANATION

Explain that the generator is not responsible for searching the document database.

Its job is only:

```text
Question
+
Retrieved context
    ↓
Language model
    ↓
Answer
```

The retriever and generator are separate components.

---

# 27. PROMPT CONSTRUCTION

Implement prompt creation manually.

Create:

```python
def build_prompt(question, retrieved_chunks):
    ...
```

Use a grounding-oriented template similar to:

```text
You are a question-answering assistant.

Answer the question using ONLY the information in the provided context.

If the answer cannot be found in the context, say:
"I could not find enough information in the provided documents."

Do not invent facts.

Context:
[Source 1]
...

[Source 2]
...

Question:
...

Answer:
```

Include numbered source markers:

```text
[1]
[2]
[3]
```

so answers can reference retrieved evidence.

---

# 28. CONTROL CONTEXT LENGTH

Do not blindly concatenate unlimited retrieved text.

Calculate or approximate prompt token length.

Respect the generator model's context window.

If necessary:

```text
reduce top_k
truncate individual chunks
```

Explain the trade-off:

```text
More retrieved context
→ potentially more evidence
→ but also more noise and more tokens
```

---

# 29. GENERATE THE ANSWER

Create:

```python
def generate_answer(
    question,
    retrieved_chunks
):
    ...
```

Use relatively deterministic settings for QA:

```text
temperature low
do_sample False
```

or equivalent.

Avoid highly creative generation.

---

# 30. COMPLETE RAG FUNCTION

Create a simple final function:

```python
def ask_rag(
    question,
    top_k=5
):
    ...
```

The function should:

```text
1. Embed question
2. Retrieve chunks
3. Construct prompt
4. Run generator
5. Return answer
6. Return sources
```

Example:

```python
result = ask_rag(
    "What is the purpose of positional encoding?"
)
```

Return a structured object such as:

```python
{
    "question": "...",
    "answer": "...",
    "sources": [...],
    "retrieved_chunks": [...]
}
```

---

# 31. SOURCE CITATIONS

Display answers with sources.

For example:

```text
Answer:

Positional encoding gives the Transformer information about the
relative or absolute position of tokens because the self-attention
mechanism itself does not encode sequence order. [1]

Sources:

[1] transformer_notes.pdf — page 6
[2] deep_learning_notes.pdf — page 14
```

Do not fabricate citations.

Only cite chunks that were actually retrieved.

---

# 32. SOURCE DEDUPLICATION

If several retrieved chunks come from the same page/file, avoid unnecessarily repeating identical source entries.

Create clean source formatting.

---

# 33. SHOW RETRIEVAL EVIDENCE

Provide an optional:

```python
show_retrieved_chunks=True
```

mode.

When enabled, display:

```text
Rank
Similarity score
Source
Page
Text
```

This is important for debugging and academic demonstration.

---

# 34. UNKNOWN / UNANSWERABLE QUESTIONS

Test a question whose answer does not exist in the knowledge base.

Example:

```text
If the documents discuss machine learning:

Question:
"Who won the FIFA World Cup in 1966?"
```

The RAG system should respond:

```text
I could not find enough information in the provided documents.
```

rather than hallucinating an answer from the generator's pretrained knowledge.

Explain that this is called **grounding**.

---

# 35. RETRIEVAL THRESHOLD

Optionally introduce a minimum similarity threshold.

For example:

```python
MIN_RETRIEVAL_SCORE = ...
```

If all retrieved chunks score poorly, warn that the knowledge base may not contain the answer.

Do not choose an arbitrary threshold without explaining that it may require tuning.

---

# 36. RAG VS NORMAL LLM TEST

Create an educational comparison.

Ask a question relating specifically to an uploaded document.

Show:

```text
Retrieved context
RAG answer
```

Explain why retrieval allows the model to answer document-specific questions.

Do not rely on the base generator's internal knowledge as the source of truth.

---

# 37. MULTIPLE QUESTIONS

Test at least 10 questions.

Include:

```text
Direct factual questions
Definition questions
Explanation questions
Questions requiring information from different chunks
An unanswerable question
```

Produce a table:

```text
Question
Answer
Top source
Top retrieval score
```

---

# 38. QUERY ABOUT MULTIPLE DOCUMENTS

If the document collection contains several files, demonstrate that the system can retrieve from different documents.

For example:

```text
Question 1 → document A
Question 2 → document B
Question 3 → document C
```

---

# 39. RETRIEVAL EVALUATION

Create a small hand-labelled retrieval evaluation set.

For example:

```python
evaluation_questions = [
    {
        "question": "...",
        "expected_source": "transformers.pdf",
        "expected_page": 5
    },
    ...
]
```

Evaluate whether the expected source appears in:

```text
Top-1
Top-3
Top-5
```

Compute:

```text
Recall@1
Recall@3
Recall@5
```

Explain that retrieval quality is separate from generation quality.

---

# 40. BASIC RAG EVALUATION

Create a small manually defined evaluation dataset containing:

```text
Question
Expected answer
Expected source
```

Evaluate:

```text
retrieval success
answer relevance
source correctness
```

Do not invent sophisticated evaluation scores without explaining them.

Where automatic evaluation is difficult, provide qualitative evaluation.

---

# 41. RAG FAILURE MODES

Include examples and explanations of:

```text
Wrong chunk retrieved
Correct chunk retrieved but poor generation
Missing information in documents
Too-large chunks
Too-small chunks
Too much irrelevant context
Hallucination
Ambiguous question
```

Explain that RAG does not automatically eliminate hallucinations.

---

# 42. CHUNK-SIZE EXPERIMENT

If practical, test at least two chunking strategies.

For example:

```text
chunk_size = 300
chunk_size = 700
```

Show how retrieval results differ for a few questions.

Explain:

```text
Small chunks
+ precise retrieval
- may lose context

Large chunks
+ preserve context
- may introduce irrelevant information
```

This can be a small experiment rather than a full benchmark.

---

# 43. TOP-K EXPERIMENT

Test:

```text
top_k = 1
top_k = 3
top_k = 5
```

for one or two questions.

Show retrieved chunks and explain the trade-off.

---

# 44. INTERACTIVE NOTEBOOK DEMO

At the end provide:

```python
MY_QUESTION = """
Enter your question here.
"""
```

Then:

```python
result = ask_rag(MY_QUESTION)
```

Display:

```text
Question
Answer
Sources
Retrieved Evidence
```

cleanly.

---

# 45. OPTIONAL GRADIO INTERFACE

Add an optional final section using Gradio.

Interface:

```text
Question input
Ask button
Answer box
Sources box
Retrieved context box
```

This section is optional.

The core notebook must work without Gradio.

---

# 46. SAVE SYSTEM ARTIFACTS

Save everything required to reuse the system.

Suggested structure:

```text
artifacts/
├── knowledge_base/
│   ├── faiss.index
│   ├── chunks.json
│   ├── metadata.json
│   └── embedding_config.json
│
├── config.json
├── evaluation_results.json
└── README.txt
```

The embedding model itself does not necessarily have to be copied if it can be loaded from Hugging Face, but provide an option to save locally if desired.

---

# 47. RELOAD WITHOUT RE-INDEXING

This is extremely important.

The notebook must support:

```python
REBUILD_INDEX = False
```

When this is set:

```text
Do not reopen and reprocess all documents.
Do not regenerate embeddings.
Do not rebuild FAISS.
```

Instead:

```text
Load saved FAISS index
Load saved chunk metadata
Load embedding model
Load generator
Start answering questions
```

---

# 48. OPTIONAL OFFLINE ARTIFACT MODE

Where practical, include instructions or code for saving:

```text
embedding model
generator model
tokenizers
FAISS index
chunk metadata
```

so the entire project can later be restored from Google Drive without downloading model files again.

This is optional because model files can be large.

---

# 49. MODEL MEMORY MANAGEMENT

Design for Colab.

Where appropriate:

```python
torch_dtype=torch.float16
```

or:

```python
device_map="auto"
```

may be used.

If quantization is used, explain it.

Do not require expensive hardware.

---

# 50. CLEAR RAG ARCHITECTURE EXPLANATION

Include this conceptual breakdown:

```text
OFFLINE / INDEXING STAGE

Documents
   ↓
Text extraction
   ↓
Chunking
   ↓
Embedding
   ↓
FAISS index


ONLINE / QUESTION STAGE

Question
   ↓
Question embedding
   ↓
FAISS retrieval
   ↓
Relevant chunks
   ↓
Prompt
   ↓
Generator
   ↓
Answer + sources
```

Explain that indexing does not need to happen for every question.

---

# 51. EXPLAIN WHY SAVING THE INDEX MATTERS

Explain that document embeddings may be expensive to recreate.

Once generated:

```text
Documents
↓
Embeddings
↓
FAISS
```

can be saved.

Later sessions can start at:

```text
Question
↓
Retrieval
↓
Generation
```

---

# 52. COMMENTS AND DOCUMENTATION

Use useful comments throughout the notebook.

Example:

```python
# Convert each document chunk into a dense vector representation.
# Similar meanings should result in nearby vectors in embedding space.
chunk_embeddings = embedding_model.encode(
    chunk_texts,
    normalize_embeddings=True
)
```

Do not comment trivial Python syntax.

Focus comments on:

```text
RAG concepts
embedding
chunking
retrieval
FAISS
prompt grounding
generation
citations
```

---

# 53. SANITY CHECKS

Before declaring the system complete, verify:

```text
Number of chunks > 0
Number of embeddings = number of chunks
Embedding dimension matches FAISS index dimension
Metadata count = chunk count
FAISS index count = chunk count
```

Use assertions where useful.

---

# 54. NO FAKE RESULTS

Do not:

* hard-code answers
* fabricate sources
* fabricate evaluation numbers
* manually insert answers for demonstration
* use external search engines to answer user questions

Every demonstrated answer must come from:

```text
retrieved documents
+
generator model
```

---

# 55. FINAL RESULT SUMMARY

At the bottom print a project summary such as:

```text
RAG SYSTEM SUMMARY

Documents indexed: 8
Pages processed: 174
Chunks generated: 1,842

Embedding model:
sentence-transformers/all-MiniLM-L6-v2

Embedding dimension:
384

Vector database:
FAISS

Generator:
...

Default chunk size:
500

Chunk overlap:
100

Top-K:
5
```

Also include a Markdown explanation of what was accomplished.

---

# 56. FINAL ACADEMIC EXPLANATION

Include a concise final explanation:

> This project implements a Retrieval-Augmented Generation system in which source documents are converted into dense vector embeddings and stored in a FAISS vector index. When a user asks a question, the question is embedded using the same embedding model and semantically similar document chunks are retrieved. These retrieved chunks are supplied as context to an instruction-tuned language model, which generates an answer grounded in the retrieved evidence.

Then explain:

> The language model itself is not trained on the uploaded documents. Instead, RAG augments the model at inference time with information retrieved from the external knowledge base.

---

# 57. IMPORTANT DIFFERENCE FROM FINE-TUNING

Include a section comparing RAG and fine-tuning.

Explain:

```text
Fine-tuning:
Changes model weights.

RAG:
Does not need to change model weights.
Adds external information at inference time.
```

Example:

```text
New document added

Fine-tuning:
Potential retraining required

RAG:
Embed new document
Add vectors to index
Immediately searchable
```

---

# 58. DIFFERENCE FROM THE PREVIOUS QA PROJECT

Include a concise comparison:

```text
Extractive QA with SQuAD v2:

Question + manually supplied context
        ↓
QA Transformer
        ↓
Answer span


RAG:

Question
        ↓
Retriever searches many documents
        ↓
Relevant context
        ↓
Generator
        ↓
Answer
```

Explain that the RAG system introduces a separate retrieval stage.

---

# 59. OPTIONAL ADVANCED EXTENSIONS

Only after the basic system works, optionally include clearly separated sections for:

```text
Hybrid search
BM25 + vector retrieval
Reranking
Metadata filtering
Query expansion
Multi-query retrieval
```

These must remain optional.

Do not make the basic implementation depend on them.

---

# 60. EXPECTED DELIVERABLES

Primary deliverable:

```text
rag_system.ipynb
```

After execution:

```text
artifacts/
├── knowledge_base/
│   ├── faiss.index
│   ├── chunks.json
│   ├── metadata.json
│   └── embedding_config.json
│
├── config.json
├── evaluation_results.json
└── README.txt
```

---

# 61. REQUIRED WORKFLOWS

The notebook should support these workflows.

## Workflow A — Build knowledge base

```python
REBUILD_INDEX = True
```

Perform:

```text
Documents
→ extraction
→ chunking
→ embeddings
→ FAISS
→ save
```

Then allow questions.

## Workflow B — Reuse knowledge base

```python
REBUILD_INDEX = False
```

Perform:

```text
Load FAISS
→ load metadata
→ ask questions
```

Do not regenerate document embeddings.

## Workflow C — Add documents

If practical, implement:

```python
add_documents(...)
```

to process new files and add their embeddings to the existing FAISS index.

Save the updated index and metadata.

---

# 62. BEFORE DECLARING THE NOTEBOOK COMPLETE

Actually verify that:

1. A fresh Colab runtime can execute the notebook sequentially.
2. Dependencies install correctly.
3. PDFs can be loaded.
4. TXT/Markdown files can be loaded.
5. Text extraction works.
6. Chunking works.
7. Every chunk retains source metadata.
8. Embeddings are generated correctly.
9. FAISS index dimensions are correct.
10. Retrieval returns relevant chunks.
11. Similarity scores are displayed.
12. FAISS index saves successfully.
13. FAISS index reloads successfully.
14. Retrieval works after reload.
15. Generator model loads successfully.
16. Prompt construction uses retrieved evidence.
17. Complete RAG inference works.
18. Source citations correspond to actual retrieved chunks.
19. An unrelated question demonstrates no-answer behavior.
20. The system does not intentionally answer from unsupported model knowledge.
21. Google Drive persistence works if enabled.
22. Saved artifacts can be reused without re-indexing.
23. Multiple documents can be searched.
24. The notebook contains useful Markdown explanations.
25. Code contains useful comments.
26. Results are produced by the implemented pipeline and are not fabricated.

Prioritize correctness, clarity, reproducibility, and academic explainability over unnecessary complexity.
