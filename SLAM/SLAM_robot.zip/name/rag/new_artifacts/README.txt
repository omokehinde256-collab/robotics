RAG System Artifacts

Knowledge base directory: artifacts/knowledge_base

Files:
- knowledge_base/faiss.index
- knowledge_base/chunks.json
- knowledge_base/metadata.json
- knowledge_base/embedding_config.json
- config.json
- evaluation_results.json

Set REBUILD_INDEX=False to reload the saved knowledge base without re-embedding documents.
