# Local RAG UI

This UI loads the saved RAG artifacts from:

```text
new/003/rag_artifacts/
```

It does not rebuild the FAISS index or regenerate document embeddings.

## Setup

Use Python 3.10, 3.11, or 3.12 if possible. PyTorch and FAISS wheels may not be available or stable for newer Python versions.

From the repository root:

```bash
cd "new/003"
python -m venv .venv
source .venv/bin/activate
pip install -r local_rag_requirements.txt
```

## Run Browser UI

```bash
python local_rag_app.py --artifacts rag_artifacts --port 7861
```

Then open:

```text
http://127.0.0.1:7861
```

## Run CLI Mode

```bash
python local_rag_app.py --artifacts rag_artifacts --cli
```

## Notes

- The app uses `faiss.index`, `chunks.json`, `metadata.json`, and `embedding_config.json`.
- It downloads the configured Hugging Face embedding and generator models the first time it runs.
- The generator uses direct `model.generate()` instead of `pipeline("text2text-generation")`.
