from __future__ import annotations

import argparse
import json
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse

import faiss
import torch
from sentence_transformers import SentenceTransformer
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer


NO_ANSWER = "I could not find enough information in the provided documents."


@dataclass
class DocumentChunk:
    chunk_id: int
    source: str
    page: Optional[int]
    text: str
    word_start: int
    word_end: int


class LocalRAG:
    def __init__(self, artifact_root: Path, device_name: str = "auto"):
        self.artifact_root = artifact_root
        self.config = self._load_config(artifact_root)
        self.kb_dir = artifact_root / "knowledge_base"
        self.index = faiss.read_index(str(self.kb_dir / "faiss.index"))
        self.chunks = self._load_chunks(self.kb_dir / "chunks.json")

        with (self.kb_dir / "embedding_config.json").open("r", encoding="utf-8") as f:
            self.embedding_config = json.load(f)

        if self.index.ntotal != len(self.chunks):
            raise ValueError(
                f"FAISS index has {self.index.ntotal} vectors but chunks.json has {len(self.chunks)} chunks."
            )

        if device_name == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device_name)

        embedding_device = "cuda" if self.device.type == "cuda" else "cpu"
        self.embedding_model = SentenceTransformer(
            self.embedding_config.get("embedding_model", self.config["embedding_model"]),
            device=embedding_device,
        )

        self.generator_tokenizer = AutoTokenizer.from_pretrained(self.config["generator_model"])
        self.generator_model = AutoModelForSeq2SeqLM.from_pretrained(self.config["generator_model"]).to(self.device)
        self.generator_model.eval()

    @staticmethod
    def _load_config(artifact_root: Path) -> Dict[str, Any]:
        config_path = artifact_root / "config.json"
        if config_path.exists():
            with config_path.open("r", encoding="utf-8") as f:
                return json.load(f)
        return {
            "embedding_model": "sentence-transformers/all-MiniLM-L6-v2",
            "generator_model": "google/flan-t5-base",
            "top_k": 5,
            "min_retrieval_score": 0.25,
            "max_new_tokens": 256,
            "max_context_words": 1600,
        }

    @staticmethod
    def _load_chunks(path: Path) -> List[DocumentChunk]:
        with path.open("r", encoding="utf-8") as f:
            return [DocumentChunk(**item) for item in json.load(f)]

    def retrieve(self, question: str, top_k: int) -> List[Dict[str, Any]]:
        query = self.embedding_model.encode(
            [question],
            normalize_embeddings=True,
            convert_to_numpy=True,
        ).astype("float32")
        scores, indices = self.index.search(query, min(top_k, self.index.ntotal))
        results: List[Dict[str, Any]] = []
        for rank, (score, idx) in enumerate(zip(scores[0], indices[0]), start=1):
            if idx < 0:
                continue
            chunk = self.chunks[int(idx)]
            results.append(
                {
                    "rank": rank,
                    "score": float(score),
                    "source": chunk.source,
                    "page": chunk.page,
                    "chunk_id": chunk.chunk_id,
                    "text": chunk.text,
                }
            )
        return results

    def trim_context(self, results: List[Dict[str, Any]], max_words: int) -> List[Dict[str, Any]]:
        selected: List[Dict[str, Any]] = []
        used = 0
        for item in results:
            words = item["text"].split()
            remaining = max_words - used
            if remaining <= 0:
                break
            clipped = dict(item)
            if len(words) > remaining:
                clipped["text"] = " ".join(words[:remaining])
            selected.append(clipped)
            used += min(len(words), remaining)
        return selected

    def build_prompt(self, question: str, retrieved_chunks: List[Dict[str, Any]]) -> str:
        blocks = []
        for marker, chunk in enumerate(retrieved_chunks, start=1):
            page = "N/A" if chunk["page"] is None else chunk["page"]
            blocks.append(
                f"[{marker}] Source: {chunk['source']} | Page: {page} | Chunk: {chunk['chunk_id']}\n"
                f"{chunk['text']}"
            )
        context = "\n\n".join(blocks)
        return f"""You are a question-answering assistant.
Answer the question using ONLY the information in the provided context.
If the answer cannot be found in the context, say exactly: {NO_ANSWER}
Do not invent facts. Include source markers like [1] only when supported.

Context:
{context}

Question:
{question}

Answer:"""

    @staticmethod
    def deduplicate_sources(results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen: set[Tuple[str, Optional[int]]] = set()
        sources = []
        for marker, chunk in enumerate(results, start=1):
            key = (chunk["source"], chunk["page"])
            if key in seen:
                continue
            seen.add(key)
            sources.append(
                {
                    "marker": f"[{marker}]",
                    "source": chunk["source"],
                    "page": chunk["page"],
                    "chunk_id": chunk["chunk_id"],
                    "score": chunk["score"],
                }
            )
        return sources

    @torch.no_grad()
    def generate_answer(self, question: str, retrieved_chunks: List[Dict[str, Any]]) -> str:
        if not retrieved_chunks:
            return NO_ANSWER
        threshold = float(self.config.get("min_retrieval_score", 0.25))
        if max(chunk["score"] for chunk in retrieved_chunks) < threshold:
            return NO_ANSWER

        prompt = self.build_prompt(
            question,
            self.trim_context(retrieved_chunks, int(self.config.get("max_context_words", 1600))),
        )
        inputs = self.generator_tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=1024,
        ).to(self.device)
        output_ids = self.generator_model.generate(
            **inputs,
            max_new_tokens=int(self.config.get("max_new_tokens", 256)),
            do_sample=False,
        )
        answer = self.generator_tokenizer.decode(output_ids[0], skip_special_tokens=True).strip()
        return answer or NO_ANSWER

    def ask(self, question: str, top_k: Optional[int] = None) -> Dict[str, Any]:
        top_k = int(top_k or self.config.get("top_k", 5))
        retrieved = self.retrieve(question, top_k=top_k)
        answer = self.generate_answer(question, retrieved)
        return {
            "question": question,
            "answer": answer,
            "sources": self.deduplicate_sources(retrieved),
            "retrieved_chunks": retrieved,
            "device": str(self.device),
            "generator_model": self.config["generator_model"],
            "embedding_model": self.embedding_config.get("embedding_model", self.config["embedding_model"]),
        }


HTML = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Local RAG Document QA</title>
  <style>
    :root { color-scheme: light; }
    body { font-family: system-ui, -apple-system, Segoe UI, sans-serif; margin: 0; background: #f5f7fb; color: #1f2937; }
    main { max-width: 1120px; margin: 28px auto; padding: 0 20px; }
    h1 { font-size: 28px; margin: 0 0 16px; }
    .panel { background: white; border: 1px solid #d8dde5; border-radius: 8px; padding: 18px; }
    textarea { width: 100%; min-height: 120px; resize: vertical; font: 16px/1.45 ui-monospace, SFMono-Regular, Menlo, monospace; padding: 12px; box-sizing: border-box; border: 1px solid #c7ced8; border-radius: 6px; }
    .row { display: flex; gap: 12px; align-items: center; margin: 14px 0; flex-wrap: wrap; }
    input { font-size: 15px; padding: 7px 9px; border: 1px solid #c7ced8; border-radius: 6px; width: 74px; }
    button { font-size: 15px; padding: 8px 14px; border: 0; border-radius: 6px; background: #155eef; color: white; cursor: pointer; }
    button:disabled { background: #8aa8ee; cursor: wait; }
    .hint { color: #64748b; font-size: 14px; }
    .grid { display: grid; grid-template-columns: minmax(0, 1fr) minmax(320px, 420px); gap: 16px; margin-top: 16px; }
    @media (max-width: 860px) { .grid { grid-template-columns: 1fr; } }
    .box { border: 1px solid #d8dde5; border-radius: 8px; padding: 14px; background: #ffffff; }
    .box h2 { font-size: 16px; margin: 0 0 10px; }
    #answer { white-space: pre-wrap; line-height: 1.55; min-height: 110px; }
    .source { border-top: 1px solid #e5e7eb; padding: 10px 0; font-size: 14px; }
    .source:first-child { border-top: 0; padding-top: 0; }
    .score { color: #475569; font-size: 13px; }
    details { border-top: 1px solid #e5e7eb; padding: 10px 0; }
    details:first-child { border-top: 0; padding-top: 0; }
    summary { cursor: pointer; font-weight: 600; }
    .chunk { white-space: pre-wrap; color: #334155; font-size: 14px; line-height: 1.45; margin-top: 8px; }
    .meta { color: #64748b; font-size: 13px; margin-top: 4px; }
  </style>
</head>
<body>
<main>
  <h1>Local RAG Document QA</h1>
  <div class="panel">
    <textarea id="question">What is Retrieval-Augmented Generation?</textarea>
    <div class="row">
      <label>Top K <input id="top_k" type="number" min="1" max="10" value="5"></label>
      <button id="go">Ask</button>
      <span class="hint" id="status"></span>
    </div>
    <div class="grid">
      <section class="box">
        <h2>Answer</h2>
        <div id="answer"></div>
      </section>
      <section class="box">
        <h2>Sources</h2>
        <div id="sources"></div>
      </section>
    </div>
    <section class="box" style="margin-top:16px">
      <h2>Retrieved Evidence</h2>
      <div id="evidence"></div>
    </section>
  </div>
</main>
<script>
const button = document.getElementById("go");

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[ch]));
}

button.addEventListener("click", async () => {
  const question = document.getElementById("question").value.trim();
  if (!question) return;
  button.disabled = true;
  document.getElementById("status").textContent = "Retrieving and generating...";
  document.getElementById("answer").textContent = "";
  document.getElementById("sources").innerHTML = "";
  document.getElementById("evidence").innerHTML = "";
  try {
    const params = new URLSearchParams({
      question,
      top_k: document.getElementById("top_k").value
    });
    const response = await fetch("/ask", {
      method: "POST",
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: params
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "RAG request failed");

    document.getElementById("answer").textContent = data.answer;
    document.getElementById("status").textContent = `${data.seconds.toFixed(2)}s on ${data.device}`;

    document.getElementById("sources").innerHTML = data.sources.map(s => {
      const page = s.page === null ? "N/A" : s.page;
      return `<div class="source"><strong>${escapeHtml(s.marker)} ${escapeHtml(s.source)}</strong><div class="score">page ${page} · chunk ${s.chunk_id} · score ${s.score.toFixed(4)}</div></div>`;
    }).join("") || "<span class='hint'>No sources.</span>";

    document.getElementById("evidence").innerHTML = data.retrieved_chunks.map(r => {
      const page = r.page === null ? "N/A" : r.page;
      return `<details><summary>Rank ${r.rank}: ${escapeHtml(r.source)} · score ${r.score.toFixed(4)}</summary><div class="meta">page ${page} · chunk ${r.chunk_id}</div><div class="chunk">${escapeHtml(r.text)}</div></details>`;
    }).join("") || "<span class='hint'>No retrieved chunks.</span>";
  } catch (error) {
    document.getElementById("answer").textContent = error.message;
    document.getElementById("status").textContent = "";
  } finally {
    button.disabled = false;
  }
});
</script>
</body>
</html>
"""


class RAGHandler(BaseHTTPRequestHandler):
    rag: LocalRAG

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/":
            self.send_error(404)
            return
        self._send(200, HTML.encode("utf-8"), "text/html; charset=utf-8")

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/ask":
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", "0"))
        data = parse_qs(self.rfile.read(length).decode("utf-8"))
        question = data.get("question", [""])[0].strip()
        top_k = int(data.get("top_k", [self.rag.config.get("top_k", 5)])[0])
        if not question:
            self._json(400, {"error": "Enter a question first."})
            return
        try:
            start = time.time()
            result = self.rag.ask(question, top_k=top_k)
            result["seconds"] = time.time() - start
            self._json(200, result)
        except Exception as exc:
            self._json(500, {"error": str(exc)})

    def log_message(self, fmt: str, *args: Any) -> None:
        print("%s - %s" % (self.address_string(), fmt % args))

    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, payload: Dict[str, Any]) -> None:
        self._send(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a local RAG document question-answering UI.")
    parser.add_argument(
        "--artifacts",
        type=Path,
        default=Path("new_artifacts"),
        help="Path to the artifact directory containing config.json and knowledge_base/.",
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7863)
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, cuda:0, etc.")
    parser.add_argument("--cli", action="store_true", help="Use terminal input instead of the browser UI.")
    args = parser.parse_args()

    artifact_root = args.artifacts.expanduser().resolve()
    print("Loading RAG artifacts from:", artifact_root)
    rag = LocalRAG(artifact_root, args.device)
    print("Loaded", len(rag.chunks), "chunks on", rag.device)
    print("Generator:", rag.config["generator_model"])
    print("Embedding model:", rag.embedding_config.get("embedding_model", rag.config["embedding_model"]))

    if args.cli:
        print("Type questions. Press Ctrl-D or Ctrl-C to exit.")
        while True:
            try:
                question = input("\nQuestion> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if question:
                result = rag.ask(question)
                print("\nAnswer>", result["answer"])
                print("Sources:")
                for source in result["sources"]:
                    page = "N/A" if source["page"] is None else source["page"]
                    print(f"  {source['marker']} {source['source']} page {page} score {source['score']:.4f}")
        return

    RAGHandler.rag = rag
    server = ThreadingHTTPServer((args.host, args.port), RAGHandler)
    print(f"Open http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server.")


if __name__ == "__main__":
    main()
