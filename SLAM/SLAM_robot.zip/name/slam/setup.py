from glob import glob
from os.path import isfile
from setuptools import setup


package_name = "my_robot_bringup"


def files(pattern):
    return [path for path in glob(pattern) if isfile(path)]


setup(
    name=package_name,
    version="0.0.1",
    packages=[package_name],
    data_files=[
        ("share/ament_index/resource_index/packages", [f"resource/{package_name}"]),
        (f"share/{package_name}", ["package.xml"]),
        (f"share/{package_name}/config", files("config/*")),
        (f"share/{package_name}/launch", files("launch/*")),
        (f"share/{package_name}/maps", files("maps/*")),
        (f"share/{package_name}/rviz", files("rviz/*")),
        (f"share/{package_name}/urdf", files("urdf/*")),
        (f"share/{package_name}/worlds", files("worlds/*")),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="student",
    maintainer_email="student@example.com",
    description="Gazebo, SLAM Toolbox, Nav2, and RViz bringup for a four-wheel robot.",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            "dynamic_obstacle = my_robot_bringup.dynamic_obstacle:main",
            "gazebo_camera_follow = my_robot_bringup.gazebo_camera_follow:main",
            "initial_pose_publisher = my_robot_bringup.initial_pose_publisher:main",
            "simple_teleop = my_robot_bringup.simple_teleop:main",
            "twist_stamper = my_robot_bringup.twist_stamper:main",
        ],
    },
)
