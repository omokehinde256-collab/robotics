# My Robot Bringup

Target stack:

- ROS2 Jazzy
- Gazebo Harmonic through `ros_gz`
- `gz_ros2_control`
- `slam_toolbox`
- Nav2
- RViz2

Current status: the base simulation launches, the robot spawns, Gazebo publishes
`/scan`, `gz_ros2_control` publishes `/odom`, `slam_toolbox` publishes `/map`,
Nav2 publishes costmaps, and the diff-drive controller is active.

Base simulation:

```bash
cd /config/workspace
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch my_robot_bringup robot_gazebo.launch.py
```

Open the Gazebo GUI:

```bash
ros2 launch my_robot_bringup robot_gazebo.launch.py gui:=true
```

Open Gazebo for clean keyboard mapping, with the moving obstacle disabled:

```bash
ros2 launch my_robot_bringup robot_gazebo.launch.py gui:=true dynamic_obstacle:=false
```

In a second terminal, verify the base topics:

```bash
cd /config/workspace
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 topic echo /scan --once
ros2 topic echo /odom --once
ros2 topic info /cmd_vel -v
```

The installed Jazzy `diff_drive_controller` expects stamped velocity commands.
This package starts `twist_stamper`, so user commands and Nav2 can publish the
normal `geometry_msgs/msg/Twist` on `/cmd_vel`; the controller receives stamped
messages on `/cmd_vel_stamped`.

```bash
ros2 topic pub /cmd_vel geometry_msgs/msg/Twist \
  "{linear: {x: 0.15}, angular: {z: 0.0}}" --once
```

Simple keyboard driving:

```bash
ros2 run my_robot_bringup simple_teleop
```

Use `w/s` forward/back, `a/d` turn, `q/e/z/c` diagonal movement, and space to
stop. Each key sets the current motion until another key or space is pressed.

SLAM, after the base simulation is already running:

```bash
ros2 launch my_robot_bringup slam.launch.py
```

Nav2, after base simulation and SLAM are running:

```bash
ros2 launch my_robot_bringup nav2_bringup.launch.py
```

Full stack:

```bash
ros2 launch my_robot_bringup full_sim.launch.py
```

Full stack with Gazebo GUI:

```bash
ros2 launch my_robot_bringup full_sim.launch.py gui:=true
```

RViz only:

```bash
ros2 launch my_robot_bringup rviz.launch.py
```

See:

```text
.midterm_notes/robo4/roadmap.md
.midterm_notes/robo4/status.md
.midterm_notes/robo4/presentation_explanation.md
```

Saved evidence:

```text
workspace/src/my_robot_bringup/maps/my_map.yaml
workspace/src/my_robot_bringup/maps/my_map.pgm
.midterm_notes/robo4/evidence/tf_tree.pdf
```

Verified navigation:

```text
/navigate_to_pose short proof goal completed with status SUCCEEDED.
Use map x=3.0, y=1.2 as the longer presentation goal.
```
