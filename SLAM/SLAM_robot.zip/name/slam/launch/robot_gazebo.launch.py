import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, RegisterEventHandler, TimerAction
from launch.conditions import IfCondition, UnlessCondition
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    use_sim_time = LaunchConfiguration("use_sim_time")
    gui = LaunchConfiguration("gui")
    dynamic_obstacle_enabled = LaunchConfiguration("dynamic_obstacle")
    follow_robot = LaunchConfiguration("follow_robot")

    pkg_share = get_package_share_directory("my_robot_bringup")
    ros_gz_sim_share = get_package_share_directory("ros_gz_sim")

    world = os.path.join(pkg_share, "worlds", "my_world.sdf")
    controllers = os.path.join(pkg_share, "config", "ros2_controllers.yaml")
    bridge_config = os.path.join(pkg_share, "config", "bridge.yaml")

    robot_description_content = Command([
        "xacro ",
        PathJoinSubstitution([
            FindPackageShare("my_robot_bringup"),
            "urdf",
            "my_robot.xacro",
        ]),
    ])

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="screen",
        parameters=[
            {"robot_description": robot_description_content},
            {"use_sim_time": use_sim_time},
        ],
    )

    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(ros_gz_sim_share, "launch", "gz_sim.launch.py")
        ),
        launch_arguments={"gz_args": f"-r -s -v 2 {world}"}.items(),
        condition=UnlessCondition(gui),
    )

    gazebo_gui = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(ros_gz_sim_share, "launch", "gz_sim.launch.py")
        ),
        launch_arguments={"gz_args": f"-r -v 2 {world}"}.items(),
        condition=IfCondition(gui),
    )

    spawn_robot = Node(
        package="ros_gz_sim",
        executable="create",
        output="screen",
        arguments=[
            "-world",
            "my_world",
            "-name",
            "my_robot",
            "-topic",
            "robot_description",
            "-x",
            "-2.8",
            "-y",
            "-2.0",
            "-z",
            "0.105",
            "-Y",
            "0.0",
        ],
    )

    joint_state_spawner = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        arguments=[
            "joint_state_broadcaster",
            "--controller-manager-timeout",
            "30",
            "--switch-timeout",
            "30",
        ],
    )

    diff_drive_spawner = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        arguments=[
            "diff_drive_controller",
            "--param-file",
            controllers,
            "--controller-manager-timeout",
            "30",
            "--switch-timeout",
            "30",
            "--controller-ros-args",
            "-r ~/odom:=/odom -r ~/cmd_vel:=/cmd_vel_stamped",
        ],
    )

    twist_stamper = Node(
        package="my_robot_bringup",
        executable="twist_stamper",
        output="screen",
        parameters=[{"use_sim_time": use_sim_time}],
    )

    dynamic_obstacle = Node(
        package="my_robot_bringup",
        executable="dynamic_obstacle",
        name="dynamic_obstacle_1",
        output="screen",
        parameters=[{
            "use_sim_time": use_sim_time,
            "model_name": "moving_obstacle",
            "x": -0.2,
            "y_center": 0.8,
            "y_amplitude": 1.0,
            "z": 0.3,
            "period": 14.0,
        }],
        condition=IfCondition(dynamic_obstacle_enabled),
    )

    dynamic_obstacle_2 = Node(
        package="my_robot_bringup",
        executable="dynamic_obstacle",
        name="dynamic_obstacle_2",
        output="screen",
        parameters=[{
            "use_sim_time": use_sim_time,
            "model_name": "moving_obstacle_2",
            "x": 2.1,
            "y_center": -0.4,
            "y_amplitude": 0.85,
            "z": 0.28,
            "period": 18.0,
        }],
        condition=IfCondition(dynamic_obstacle_enabled),
    )

    dynamic_obstacle_3 = Node(
        package="my_robot_bringup",
        executable="dynamic_obstacle",
        name="dynamic_obstacle_3",
        output="screen",
        parameters=[{
            "use_sim_time": use_sim_time,
            "model_name": "moving_obstacle_3",
            "x": -1.9,
            "y_center": 0.3,
            "y_amplitude": 0.65,
            "z": 0.25,
            "period": 22.0,
        }],
        condition=IfCondition(dynamic_obstacle_enabled),
    )

    bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        output="screen",
        parameters=[{"config_file": bridge_config}],
    )

    gazebo_camera_follow = Node(
        package="my_robot_bringup",
        executable="gazebo_camera_follow",
        output="screen",
        parameters=[
            {"model_name": "my_robot"},
            {"startup_delay": 8.0},
            {"distance": 4.5},
            {"height": 2.6},
            {"side_offset": -1.2},
            {"publish_period": 2.0},
        ],
        condition=IfCondition(follow_robot),
    )

    return LaunchDescription([
        DeclareLaunchArgument("use_sim_time", default_value="true"),
        DeclareLaunchArgument("gui", default_value="false"),
        DeclareLaunchArgument("dynamic_obstacle", default_value="true"),
        DeclareLaunchArgument("follow_robot", default_value="false"),
        gazebo_server,
        gazebo_gui,
        bridge,
        robot_state_publisher,
        twist_stamper,
        dynamic_obstacle,
        dynamic_obstacle_2,
        dynamic_obstacle_3,
        spawn_robot,
        TimerAction(period=2.0, actions=[gazebo_camera_follow]),
        RegisterEventHandler(
            OnProcessExit(
                target_action=spawn_robot,
                on_exit=[joint_state_spawner],
            )
        ),
        RegisterEventHandler(
            OnProcessExit(
                target_action=joint_state_spawner,
                on_exit=[diff_drive_spawner],
            )
        ),
    ])
