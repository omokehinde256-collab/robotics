from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def package_launch(filename, launch_arguments=None):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("my_robot_bringup"),
                "launch",
                filename,
            ])
        ),
        launch_arguments=(launch_arguments or {}).items(),
    )


def generate_launch_description():
    gui = LaunchConfiguration("gui")
    rviz = LaunchConfiguration("rviz")
    follow_robot = LaunchConfiguration("follow_robot")

    return LaunchDescription([
        DeclareLaunchArgument("gui", default_value="true"),
        DeclareLaunchArgument("rviz", default_value="true"),
        DeclareLaunchArgument("follow_robot", default_value="false"),
        package_launch(
            "robot_gazebo.launch.py",
            {
                "gui": gui,
                "dynamic_obstacle": "false",
                "follow_robot": follow_robot,
            },
        ),
        TimerAction(period=8.0, actions=[package_launch("slam.launch.py")]),
        TimerAction(
            period=12.0,
            actions=[package_launch("rviz.launch.py")],
            condition=IfCondition(rviz),
        ),
    ])
