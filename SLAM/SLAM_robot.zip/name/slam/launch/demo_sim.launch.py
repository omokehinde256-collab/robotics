from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def package_launch(filename, launch_arguments=None):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("my_robot_bringup"),
                "launch",
                filename,
            ])
        ),
        launch_arguments=(launch_arguments or {}).items(),
    )


def generate_launch_description():
    gui = LaunchConfiguration("gui")
    rviz = LaunchConfiguration("rviz")
    dynamic_obstacle = LaunchConfiguration("dynamic_obstacle")
    follow_robot = LaunchConfiguration("follow_robot")
    initial_x = LaunchConfiguration("initial_x")
    initial_y = LaunchConfiguration("initial_y")
    initial_yaw = LaunchConfiguration("initial_yaw")

    initial_pose = Node(
        package="my_robot_bringup",
        executable="initial_pose_publisher",
        output="screen",
        parameters=[
            {"use_sim_time": True},
            {"x": initial_x},
            {"y": initial_y},
            {"yaw": initial_yaw},
        ],
    )

    return LaunchDescription([
        DeclareLaunchArgument("gui", default_value="false"),
        DeclareLaunchArgument("rviz", default_value="true"),
        DeclareLaunchArgument("dynamic_obstacle", default_value="false"),
        DeclareLaunchArgument("follow_robot", default_value="true"),
        DeclareLaunchArgument("initial_x", default_value="0.0"),
        DeclareLaunchArgument("initial_y", default_value="0.0"),
        DeclareLaunchArgument("initial_yaw", default_value="0.0"),
        package_launch(
            "robot_gazebo.launch.py",
            {
                "gui": gui,
                "dynamic_obstacle": dynamic_obstacle,
                "follow_robot": follow_robot,
            },
        ),
        TimerAction(period=8.0, actions=[package_launch("localization.launch.py")]),
        TimerAction(period=11.0, actions=[initial_pose]),
        TimerAction(period=14.0, actions=[package_launch("nav2_bringup.launch.py")]),
        TimerAction(
            period=18.0,
            actions=[package_launch("rviz.launch.py")],
            condition=IfCondition(rviz),
        ),
    ])
