from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def package_launch(filename, launch_arguments=None):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("my_robot_bringup"),
                "launch",
                filename,
            ])
        ),
        launch_arguments=(launch_arguments or {}).items(),
    )


def generate_launch_description():
    gui = LaunchConfiguration("gui")
    dynamic_obstacle = LaunchConfiguration("dynamic_obstacle")

    return LaunchDescription([
        DeclareLaunchArgument("gui", default_value="false"),
        DeclareLaunchArgument("dynamic_obstacle", default_value="true"),
        package_launch(
            "robot_gazebo.launch.py",
            {
                "gui": gui,
                "dynamic_obstacle": dynamic_obstacle,
            },
        ),
        TimerAction(period=8.0, actions=[package_launch("slam.launch.py")]),
        TimerAction(period=14.0, actions=[package_launch("nav2_bringup.launch.py")]),
        TimerAction(period=18.0, actions=[package_launch("rviz.launch.py")]),
    ])
