import math
import subprocess

import rclpy
from rclpy.node import Node


class DynamicObstacle(Node):
    def __init__(self):
        super().__init__("dynamic_obstacle")
        self.world = self.declare_parameter("world", "my_world").value
        self.model_name = self.declare_parameter("model_name", "moving_obstacle").value
        self.x = float(self.declare_parameter("x", -0.2).value)
        self.y_center = float(self.declare_parameter("y_center", 0.8).value)
        self.y_amplitude = float(self.declare_parameter("y_amplitude", 1.0).value)
        self.z = float(self.declare_parameter("z", 0.3).value)
        self.period = float(self.declare_parameter("period", 14.0).value)
        self.start_time = self.get_clock().now()
        self.timer = self.create_timer(0.5, self.update_pose)

    def update_pose(self):
        elapsed = (self.get_clock().now() - self.start_time).nanoseconds / 1e9
        phase = (2.0 * math.pi * elapsed) / self.period
        y = self.y_center + self.y_amplitude * math.sin(phase)
        request = (
            f'name: "{self.model_name}" '
            f"position {{x: {self.x:.3f} y: {y:.3f} z: {self.z:.3f}}} "
            "orientation {w: 1.0}"
        )
        subprocess.run(
            [
                "gz",
                "service",
                "-s",
                f"/world/{self.world}/set_pose",
                "--reqtype",
                "gz.msgs.Pose",
                "--reptype",
                "gz.msgs.Boolean",
                "--timeout",
                "200",
                "--req",
                request,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )


def main():
    rclpy.init()
    node = DynamicObstacle()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
