import subprocess
import time

import rclpy
from rclpy.node import Node


class GazeboCameraFollow(Node):
    def __init__(self):
        super().__init__("gazebo_camera_follow")
        self.model_name = self.declare_parameter("model_name", "my_robot").value
        self.enabled = bool(self.declare_parameter("enabled", True).value)
        self.startup_delay = float(self.declare_parameter("startup_delay", 6.0).value)
        self.distance = float(self.declare_parameter("distance", 4.5).value)
        self.height = float(self.declare_parameter("height", 2.6).value)
        self.side_offset = float(self.declare_parameter("side_offset", -1.2).value)
        self.publish_period = float(self.declare_parameter("publish_period", 2.0).value)
        self.max_wait_attempts = int(self.declare_parameter("max_wait_attempts", 12).value)
        self._timer = None

    def run(self):
        if not self.enabled:
            self.get_logger().info("Gazebo camera follow is disabled.")
            return False

        self.get_logger().info(
            f"Waiting {self.startup_delay:.1f}s for Gazebo GUI camera plugins."
        )
        time.sleep(self.startup_delay)

        if not self._wait_for_track_topic():
            self.get_logger().warning(
                "Gazebo GUI camera tracking topic /gui/track was not found. "
                "If the GUI is open, right-click my_robot in Gazebo and choose "
                "a follow/track option manually."
            )
            return False

        self._move_to_model()
        self._publish_track_request()
        self._timer = self.create_timer(self.publish_period, self._publish_track_request)
        self.get_logger().info(f"Gazebo camera is tracking model '{self.model_name}'.")
        return True

    def _wait_for_track_topic(self):
        for attempt in range(1, self.max_wait_attempts + 1):
            topics = self._gz_topic_list()
            if "/gui/track" in topics:
                return True
            self.get_logger().info(
                f"Waiting for /gui/track ({attempt}/{self.max_wait_attempts})."
            )
            time.sleep(1.0)
        return False

    def _gz_topic_list(self):
        result = subprocess.run(
            ["gz", "topic", "-l"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            check=False,
        )
        return result.stdout.splitlines()

    def _move_to_model(self):
        request = (
            f'name: "{self.model_name}", '
            f"pose: {{position: {{z: {self.distance:.3f}}}, "
            "orientation: {x: 0, y: 0, z: -0.9238795, w: 0.3826834}}}, "
            'projection_type: "orbit"'
        )
        result = subprocess.run(
            [
                "gz",
                "service",
                "-s",
                "/gui/move_to/model",
                "--reqtype",
                "gz.msgs.GUICamera",
                "--reptype",
                "gz.msgs.Boolean",
                "--timeout",
                "5000",
                "--req",
                request,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if result.returncode != 0:
            self.get_logger().warning(
                "Could not move Gazebo camera to the robot before tracking."
            )

    def _publish_track_request(self):
        request = (
            f'name: "{self.model_name}", '
            f'track: {{name: "{self.model_name}", '
            "inherit_orientation: false, "
            "inherit_yaw: true, "
            f"xyz: {{x: {self.side_offset:.3f}, y: 0.000, z: {self.height:.3f}}}, "
            "min_dist: 2.5, "
            "max_dist: 8.0}, "
            'projection_type: "orbit"'
        )
        result = subprocess.run(
            [
                "gz",
                "topic",
                "-t",
                "/gui/track",
                "-m",
                "gz.msgs.GUICamera",
                "-p",
                request,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        if result.returncode != 0:
            self.get_logger().warning("Could not publish Gazebo camera track request.")


def main():
    rclpy.init()
    node = GazeboCameraFollow()
    try:
        if node.run():
            rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
