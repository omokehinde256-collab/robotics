import math

import rclpy
from geometry_msgs.msg import PoseWithCovarianceStamped
from rclpy.node import Node


class InitialPosePublisher(Node):
    def __init__(self):
        super().__init__("initial_pose_publisher")
        self.x = float(self.declare_parameter("x", 0.0).value)
        self.y = float(self.declare_parameter("y", 0.0).value)
        self.yaw = float(self.declare_parameter("yaw", 0.0).value)
        self.publish_count = int(self.declare_parameter("publish_count", 5).value)
        self.sent_count = 0
        self.publisher = self.create_publisher(PoseWithCovarianceStamped, "/initialpose", 10)
        self.timer = self.create_timer(0.5, self.publish_initial_pose)

    def publish_initial_pose(self):
        msg = PoseWithCovarianceStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "map"
        msg.pose.pose.position.x = self.x
        msg.pose.pose.position.y = self.y
        msg.pose.pose.orientation.z = math.sin(self.yaw / 2.0)
        msg.pose.pose.orientation.w = math.cos(self.yaw / 2.0)
        msg.pose.covariance[0] = 0.25
        msg.pose.covariance[7] = 0.25
        msg.pose.covariance[35] = 0.0685
        self.publisher.publish(msg)
        self.sent_count += 1
        if self.sent_count >= self.publish_count:
            self.get_logger().info(
                f"Published initial pose x={self.x:.2f}, y={self.y:.2f}, yaw={self.yaw:.2f}"
            )
            rclpy.shutdown()


def main():
    rclpy.init()
    node = InitialPosePublisher()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
