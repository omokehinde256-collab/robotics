import select
import sys
import termios
import tty

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node


HELP = """
Simple teleop controls

  q    w    e        forward-left, forward, forward-right
  a  space d        turn-left, stop, turn-right
  z    s    c        back-left, backward, back-right

  + / -             increase / decrease all speed
  r / f             increase / decrease linear speed
  t / g             increase / decrease angular speed
  Ctrl-C            quit
"""


KEYS = {
    "w": (1.0, 0.0),
    "s": (-1.0, 0.0),
    "a": (0.0, 1.0),
    "d": (0.0, -1.0),
    "q": (1.0, 1.0),
    "e": (1.0, -1.0),
    "z": (-1.0, -1.0),
    "c": (-1.0, 1.0),
    " ": (0.0, 0.0),
}


class SimpleTeleop(Node):
    def __init__(self):
        super().__init__("simple_teleop")
        self.pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.linear_speed = 0.2
        self.angular_speed = 0.8
        self.linear_scale = 0.0
        self.angular_scale = 0.0
        self.timer = self.create_timer(0.1, self.publish_current)

    def publish_current(self):
        msg = Twist()
        msg.linear.x = self.linear_speed * self.linear_scale
        msg.angular.z = self.angular_speed * self.angular_scale
        self.pub.publish(msg)

    def set_motion(self, linear_scale, angular_scale):
        self.linear_scale = linear_scale
        self.angular_scale = angular_scale
        self.publish_current()

    def print_speed(self):
        print(f"linear={self.linear_speed:.2f} m/s angular={self.angular_speed:.2f} rad/s")


def read_key(settings):
    tty.setraw(sys.stdin.fileno())
    ready, _, _ = select.select([sys.stdin], [], [], 0.1)
    key = sys.stdin.read(1) if ready else ""
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key


def main():
    settings = termios.tcgetattr(sys.stdin)
    rclpy.init()
    node = SimpleTeleop()
    print(HELP)
    node.print_speed()

    try:
        while rclpy.ok():
            key = read_key(settings)
            if key == "\x03":
                break
            if key in KEYS:
                node.set_motion(*KEYS[key])
            elif key in ("+", "="):
                node.linear_speed *= 1.1
                node.angular_speed *= 1.1
                node.print_speed()
            elif key == "-":
                node.linear_speed *= 0.9
                node.angular_speed *= 0.9
                node.print_speed()
            elif key == "r":
                node.linear_speed *= 1.1
                node.print_speed()
            elif key == "f":
                node.linear_speed *= 0.9
                node.print_speed()
            elif key == "t":
                node.angular_speed *= 1.1
                node.print_speed()
            elif key == "g":
                node.angular_speed *= 0.9
                node.print_speed()
            rclpy.spin_once(node, timeout_sec=0.0)
    finally:
        node.set_motion(0.0, 0.0)
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
