from __future__ import annotations

import argparse
from pathlib import Path

import torch
from transformers import MarianMTModel, MarianTokenizer

from transformer.model import TransformerSeq2Seq, greedy_decode


MODEL_NAME = "Helsinki-NLP/opus-mt-es-en"


def build_scratch_model(hf_model: MarianMTModel, tokenizer: MarianTokenizer) -> TransformerSeq2Seq:
    cfg = hf_model.config
    model = TransformerSeq2Seq(
        vocab_size=cfg.vocab_size,
        d_model=cfg.d_model,
        num_heads=cfg.encoder_attention_heads,
        d_ff=cfg.encoder_ffn_dim,
        num_encoder_layers=cfg.encoder_layers,
        num_decoder_layers=cfg.decoder_layers,
        pad_token_id=tokenizer.pad_token_id,
        max_len=cfg.max_position_embeddings,
        dropout=0.0,
        position_offset=0,
        tie_embeddings=True,
        activation=cfg.activation_function,
    )
    load_marian_weights(model, hf_model)
    model.eval()
    return model


def copy_linear(dst: torch.nn.Linear, src: torch.nn.Linear) -> None:
    dst.weight.data.copy_(src.weight.data)
    if dst.bias is not None and src.bias is not None:
        dst.bias.data.copy_(src.bias.data)


def copy_layer_norm(dst: torch.nn.LayerNorm, src: torch.nn.LayerNorm) -> None:
    dst.weight.data.copy_(src.weight.data)
    dst.bias.data.copy_(src.bias.data)


def load_marian_weights(dst: TransformerSeq2Seq, src: MarianMTModel) -> None:
    """Map HuggingFace Marian weights onto the hand-written modules.

    Main name mapping:
    - model.shared.weight -> encoder.embed_tokens.embedding.weight
      The scratch model ties encoder embeddings, decoder embeddings, and lm_head.
    - model.encoder.layers.i.self_attn.{q,k,v,out}_proj -> encoder.layers.i.self_attn.*
    - model.encoder.layers.i.self_attn_layer_norm -> encoder.layers.i.self_attn_layer_norm
    - model.encoder.layers.i.fc1/fc2 -> encoder.layers.i.ffn.fc1/fc2
    - model.encoder.layers.i.final_layer_norm -> encoder.layers.i.final_layer_norm
    - model.decoder.layers.i.self_attn.* -> decoder.layers.i.self_attn.*
    - model.decoder.layers.i.encoder_attn.* -> decoder.layers.i.encoder_attn.*
    - model.decoder.layers.i.{self_attn,encoder_attn,final}_layer_norm
      -> decoder.layers.i matching layer norms.
    - final_logits_bias -> final_logits_bias. Marian's lm_head is tied to shared.weight.
    """
    src_model = src.model
    dst.encoder.embed_tokens.embedding.weight.data.copy_(src_model.shared.weight.data)
    dst.decoder.embed_tokens.embedding.weight = dst.encoder.embed_tokens.embedding.weight
    dst.lm_head.weight = dst.encoder.embed_tokens.embedding.weight
    dst.final_logits_bias.data.copy_(src.final_logits_bias.data)
    # Marian's positional encoding is sinusoidal but laid out as
    # [sin frequencies..., cos frequencies...] instead of the paper's alternating
    # [sin, cos, sin, cos...] columns. Copy the static sinusoidal tables so
    # validation is against the exact pretrained architecture.
    dst.encoder.embed_positions.pe = src_model.encoder.embed_positions.weight.detach().clone()
    dst.decoder.embed_positions.pe = src_model.decoder.embed_positions.weight.detach().clone()

    for i, (d_layer, s_layer) in enumerate(zip(dst.encoder.layers, src_model.encoder.layers)):
        copy_linear(d_layer.self_attn.q_proj, s_layer.self_attn.q_proj)
        copy_linear(d_layer.self_attn.k_proj, s_layer.self_attn.k_proj)
        copy_linear(d_layer.self_attn.v_proj, s_layer.self_attn.v_proj)
        copy_linear(d_layer.self_attn.out_proj, s_layer.self_attn.out_proj)
        copy_layer_norm(d_layer.self_attn_layer_norm, s_layer.self_attn_layer_norm)
        copy_linear(d_layer.ffn.fc1, s_layer.fc1)
        copy_linear(d_layer.ffn.fc2, s_layer.fc2)
        copy_layer_norm(d_layer.final_layer_norm, s_layer.final_layer_norm)

    for i, (d_layer, s_layer) in enumerate(zip(dst.decoder.layers, src_model.decoder.layers)):
        copy_linear(d_layer.self_attn.q_proj, s_layer.self_attn.q_proj)
        copy_linear(d_layer.self_attn.k_proj, s_layer.self_attn.k_proj)
        copy_linear(d_layer.self_attn.v_proj, s_layer.self_attn.v_proj)
        copy_linear(d_layer.self_attn.out_proj, s_layer.self_attn.out_proj)
        copy_layer_norm(d_layer.self_attn_layer_norm, s_layer.self_attn_layer_norm)

        copy_linear(d_layer.encoder_attn.q_proj, s_layer.encoder_attn.q_proj)
        copy_linear(d_layer.encoder_attn.k_proj, s_layer.encoder_attn.k_proj)
        copy_linear(d_layer.encoder_attn.v_proj, s_layer.encoder_attn.v_proj)
        copy_linear(d_layer.encoder_attn.out_proj, s_layer.encoder_attn.out_proj)
        copy_layer_norm(d_layer.encoder_attn_layer_norm, s_layer.encoder_attn_layer_norm)

        copy_linear(d_layer.ffn.fc1, s_layer.fc1)
        copy_linear(d_layer.ffn.fc2, s_layer.fc2)
        copy_layer_norm(d_layer.final_layer_norm, s_layer.final_layer_norm)


@torch.no_grad()
def validate(sentences: list[str], max_new_tokens: int = 80) -> None:
    tokenizer = MarianTokenizer.from_pretrained(MODEL_NAME)
    hf_model = MarianMTModel.from_pretrained(MODEL_NAME).eval()
    scratch = build_scratch_model(hf_model, tokenizer)

    batch = tokenizer(sentences, return_tensors="pt", padding=True, truncation=True)
    decoder_start = hf_model.config.decoder_start_token_id
    scratch_ids = greedy_decode(
        scratch,
        batch["input_ids"],
        decoder_start_token_id=decoder_start,
        eos_token_id=tokenizer.eos_token_id,
        max_new_tokens=max_new_tokens,
        bad_token_ids=[tokenizer.pad_token_id],
    )
    hf_ids = hf_model.generate(
        **batch,
        do_sample=False,
        num_beams=1,
        max_new_tokens=max_new_tokens,
    )
    scratch_text = tokenizer.batch_decode(scratch_ids, skip_special_tokens=True)
    hf_text = tokenizer.batch_decode(hf_ids, skip_special_tokens=True)

    print("Validation against MarianMTModel greedy generation")
    for src, ours, hf in zip(sentences, scratch_text, hf_text):
        print(f"\nES:   {src}\nOURS: {ours}\nHF:   {hf}\nMATCH: {ours == hf}")


def save_checkpoint(path: Path) -> None:
    tokenizer = MarianTokenizer.from_pretrained(MODEL_NAME)
    hf_model = MarianMTModel.from_pretrained(MODEL_NAME).eval()
    scratch = build_scratch_model(hf_model, tokenizer)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(scratch.state_dict(), path)
    print(f"Saved scratch model state_dict to {path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", type=Path, default=None)
    args = parser.parse_args()
    validate(
        [
            "En el principio creó Dios los cielos y la tierra.",
            "Y dijo Dios: Sea la luz: y fué la luz.",
            "Y vió Dios que era bueno.",
        ]
    )
    if args.save:
        save_checkpoint(args.save)


if __name__ == "__main__":
    main()
