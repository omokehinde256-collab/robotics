from __future__ import annotations

import math
from collections import Counter

import torch
from torch import nn
from torch.utils.data import DataLoader

from transformer.model import TransformerSeq2Seq


PAIRS = [
    ("hola", "hello"),
    ("adios", "goodbye"),
    ("gracias", "thank you"),
    ("buenos dias", "good morning"),
    ("buenas noches", "good night"),
    ("yo veo la luz", "i see the light"),
    ("dios hizo la tierra", "god made the earth"),
    ("la luz era buena", "the light was good"),
] * 64

PAD, BOS, EOS, UNK = "<pad>", "<bos>", "<eos>", "<unk>"


class WordVocab:
    def __init__(self, texts: list[str]):
        counts = Counter(tok for text in texts for tok in text.split())
        self.itos = [PAD, BOS, EOS, UNK] + sorted(counts)
        self.stoi = {tok: i for i, tok in enumerate(self.itos)}

    def encode(self, text: str, max_len: int) -> list[int]:
        ids = [self.stoi[BOS]]
        ids += [self.stoi.get(tok, self.stoi[UNK]) for tok in text.split()]
        ids += [self.stoi[EOS]]
        ids = ids[:max_len]
        return ids + [self.stoi[PAD]] * (max_len - len(ids))

    def decode(self, ids: list[int]) -> str:
        toks = []
        for idx in ids:
            tok = self.itos[idx]
            if tok == EOS:
                break
            if tok not in {PAD, BOS}:
                toks.append(tok)
        return " ".join(toks)


def collate(batch, src_vocab: WordVocab, tgt_vocab: WordVocab, max_len: int = 10):
    src = torch.tensor([src_vocab.encode(s, max_len) for s, _ in batch], dtype=torch.long)
    tgt = torch.tensor([tgt_vocab.encode(t, max_len) for _, t in batch], dtype=torch.long)
    return src, tgt[:, :-1], tgt[:, 1:]


def main() -> None:
    torch.manual_seed(7)
    src_vocab = WordVocab([s for s, _ in PAIRS])
    tgt_vocab = WordVocab([t for _, t in PAIRS])
    loader = DataLoader(
        PAIRS,
        batch_size=16,
        shuffle=True,
        collate_fn=lambda b: collate(b, src_vocab, tgt_vocab),
    )
    model = TransformerSeq2Seq(
        vocab_size=max(len(src_vocab.itos), len(tgt_vocab.itos)),
        d_model=64,
        num_heads=4,
        d_ff=128,
        num_encoder_layers=2,
        num_decoder_layers=2,
        pad_token_id=src_vocab.stoi[PAD],
        max_len=16,
        dropout=0.1,
        tie_embeddings=False,
    )
    loss_fn = nn.CrossEntropyLoss(ignore_index=tgt_vocab.stoi[PAD])
    opt = torch.optim.AdamW(model.parameters(), lr=3e-4)

    for epoch in range(1, 11):
        total = 0.0
        for src, decoder_in, labels in loader:
            opt.zero_grad(set_to_none=True)
            logits = model(src, decoder_in).logits
            loss = loss_fn(logits.reshape(-1, logits.size(-1)), labels.reshape(-1))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            total += float(loss)
        print(f"epoch={epoch:02d} loss={total / len(loader):.4f} ppl={math.exp(total / len(loader)):.2f}")

    model.eval()
    sample = "yo veo la luz"
    src = torch.tensor([src_vocab.encode(sample, 10)])
    generated = torch.tensor([[tgt_vocab.stoi[BOS]]])
    with torch.no_grad():
        for _ in range(8):
            nxt = model(src, generated).logits[:, -1].argmax(dim=-1, keepdim=True)
            generated = torch.cat([generated, nxt], dim=1)
            if int(nxt) == tgt_vocab.stoi[EOS]:
                break
    print(f"{sample!r} -> {tgt_vocab.decode(generated[0].tolist())!r}")


if __name__ == "__main__":
    main()

