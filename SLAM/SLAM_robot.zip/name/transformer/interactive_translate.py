from __future__ import annotations

import torch
from transformers import MarianMTModel, MarianTokenizer

from load_pretrained import MODEL_NAME, build_scratch_model
from transformer.model import greedy_decode


@torch.no_grad()
def translate(text: str, tokenizer, hf_model, scratch_model, max_new_tokens: int = 96) -> str:
    batch = tokenizer([text], return_tensors="pt", truncation=True)
    output_ids = greedy_decode(
        scratch_model,
        batch["input_ids"],
        decoder_start_token_id=hf_model.config.decoder_start_token_id,
        eos_token_id=tokenizer.eos_token_id,
        max_new_tokens=max_new_tokens,
        bad_token_ids=[tokenizer.pad_token_id],
    )
    return tokenizer.decode(output_ids[0], skip_special_tokens=True)


def main() -> None:
    print("Loading Marian tokenizer, HuggingFace weights, and scratch Transformer...")
    tokenizer = MarianTokenizer.from_pretrained(MODEL_NAME)
    hf_model = MarianMTModel.from_pretrained(MODEL_NAME).eval()
    scratch_model = build_scratch_model(hf_model, tokenizer).eval()
    print("Ready. Type a Spanish sentence. Type `quit` to stop.\n")

    while True:
        text = input("Spanish> ").strip()
        if text.lower() in {"quit", "exit", "q"}:
            break
        if not text:
            continue
        print("English>", translate(text, tokenizer, hf_model, scratch_model))
        print()


if __name__ == "__main__":
    main()

