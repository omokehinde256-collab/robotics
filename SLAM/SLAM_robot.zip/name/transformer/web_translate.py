from __future__ import annotations

import argparse
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict
from urllib.parse import parse_qs, urlparse

import torch
from transformers import MarianMTModel, MarianTokenizer

from load_pretrained import MODEL_NAME, build_scratch_model
from transformer.model import greedy_decode


HTML = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Part 1 Scratch Transformer Translator</title>
  <style>
    body {
      margin: 0;
      background: #f5f7fb;
      color: #1f2937;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    main {
      max-width: 920px;
      margin: 32px auto;
      padding: 0 20px;
    }
    h1 {
      margin: 0 0 8px;
      font-size: 28px;
      line-height: 1.15;
    }
    .sub {
      margin: 0 0 18px;
      color: #64748b;
      font-size: 14px;
    }
    .panel {
      background: #ffffff;
      border: 1px solid #d8dde7;
      border-radius: 8px;
      padding: 18px;
    }
    textarea {
      width: 100%;
      min-height: 150px;
      box-sizing: border-box;
      resize: vertical;
      border: 1px solid #c7ceda;
      border-radius: 6px;
      padding: 12px;
      font: 16px/1.45 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    }
    .row {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 12px;
      margin: 14px 0;
    }
    input {
      width: 86px;
      border: 1px solid #c7ceda;
      border-radius: 6px;
      padding: 7px 9px;
      font-size: 15px;
    }
    button {
      border: 0;
      border-radius: 6px;
      padding: 8px 14px;
      background: #155eef;
      color: #ffffff;
      font-size: 15px;
      cursor: pointer;
    }
    button:disabled {
      background: #8aa8ee;
      cursor: wait;
    }
    #output {
      min-height: 92px;
      padding: 14px;
      border-radius: 6px;
      background: #111827;
      color: #f9fafb;
      white-space: pre-wrap;
      line-height: 1.5;
    }
    .hint {
      color: #64748b;
      font-size: 14px;
    }
  </style>
</head>
<body>
<main>
  <h1>Spanish to English Translator</h1>
  <p class="sub">Part 1 scratch Transformer loaded with Marian weights. Greedy decoding only.</p>
  <div class="panel">
    <textarea id="text">En el principio creó Dios los cielos y la tierra.</textarea>
    <div class="row">
      <label>Max new tokens
        <input id="max_new_tokens" type="number" min="8" max="256" value="96">
      </label>
      <button id="go">Translate</button>
      <span class="hint" id="status"></span>
    </div>
    <div id="output"></div>
  </div>
</main>
<script>
const button = document.getElementById("go");
button.addEventListener("click", async () => {
  button.disabled = true;
  document.getElementById("status").textContent = "Translating...";
  document.getElementById("output").textContent = "";
  try {
    const params = new URLSearchParams({
      text: document.getElementById("text").value,
      max_new_tokens: document.getElementById("max_new_tokens").value
    });
    const response = await fetch("/translate", {
      method: "POST",
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
      body: params
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Translation failed");
    document.getElementById("output").textContent = data.translation;
    document.getElementById("status").textContent = `${data.seconds.toFixed(2)}s on ${data.device}`;
  } catch (error) {
    document.getElementById("output").textContent = error.message;
    document.getElementById("status").textContent = "";
  } finally {
    button.disabled = false;
  }
});
</script>
</body>
</html>
"""


class ScratchMarianTranslator:
    def __init__(self, device_name: str = "auto") -> None:
        if device_name == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device_name)

        print("Loading Marian tokenizer and pretrained weights...")
        self.tokenizer = MarianTokenizer.from_pretrained(MODEL_NAME)
        hf_model = MarianMTModel.from_pretrained(MODEL_NAME).eval()
        self.decoder_start_token_id = hf_model.config.decoder_start_token_id
        self.eos_token_id = self.tokenizer.eos_token_id
        self.pad_token_id = self.tokenizer.pad_token_id

        print("Mapping Marian weights into the hand-written Transformer...")
        self.model = build_scratch_model(hf_model, self.tokenizer).to(self.device).eval()
        print("Ready on", self.device)

    @torch.no_grad()
    def translate(self, text: str, max_new_tokens: int = 96) -> str:
        batch = self.tokenizer([text], return_tensors="pt", truncation=True)
        input_ids = batch["input_ids"].to(self.device)
        output_ids = greedy_decode(
            self.model,
            input_ids,
            decoder_start_token_id=self.decoder_start_token_id,
            eos_token_id=self.eos_token_id,
            max_new_tokens=max_new_tokens,
            bad_token_ids=[self.pad_token_id],
        )
        return self.tokenizer.decode(output_ids[0].cpu(), skip_special_tokens=True)


class TranslateHandler(BaseHTTPRequestHandler):
    translator: ScratchMarianTranslator

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/":
            self.send_error(404)
            return
        self._send(200, HTML.encode("utf-8"), "text/html; charset=utf-8")

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/translate":
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", "0"))
        payload = parse_qs(self.rfile.read(length).decode("utf-8"))
        text = payload.get("text", [""])[0].strip()
        max_new_tokens = int(payload.get("max_new_tokens", ["96"])[0])
        max_new_tokens = max(8, min(256, max_new_tokens))
        if not text:
            self._json(400, {"error": "Enter Spanish text first."})
            return

        try:
            start = time.time()
            translation = self.translator.translate(text, max_new_tokens=max_new_tokens)
            self._json(
                200,
                {
                    "translation": translation,
                    "seconds": time.time() - start,
                    "device": str(self.translator.device),
                },
            )
        except Exception as exc:
            self._json(500, {"error": str(exc)})

    def log_message(self, fmt: str, *args: Any) -> None:
        print("%s - %s" % (self.address_string(), fmt % args))

    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, payload: Dict[str, Any]) -> None:
        self._send(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a browser UI for the Part 1 scratch Transformer translator.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7861)
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, cuda:0, etc.")
    parser.add_argument("--cli", action="store_true", help="Use terminal input instead of the browser UI.")
    parser.add_argument("--max-new-tokens", type=int, default=96)
    args = parser.parse_args()

    translator = ScratchMarianTranslator(args.device)

    if args.cli:
        print("Type Spanish text. Press Ctrl-D or Ctrl-C to exit.")
        while True:
            try:
                text = input("\nSpanish> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if text:
                print("English>", translator.translate(text, max_new_tokens=args.max_new_tokens))
        return

    TranslateHandler.translator = translator
    server = ThreadingHTTPServer((args.host, args.port), TranslateHandler)
    print(f"Open http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server.")


if __name__ == "__main__":
    main()
