from __future__ import annotations

import re
from pathlib import Path

import torch
from transformers import MarianMTModel, MarianTokenizer

from load_pretrained import MODEL_NAME, build_scratch_model
from transformer.model import greedy_decode


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "outputs"


def split_verse(line: str) -> tuple[str, str]:
    match = re.match(r"^(\d+)\.\s*(.*)$", line.strip())
    if not match:
        return "", line.strip()
    return match.group(1), match.group(2)


@torch.no_grad()
def translate_lines(lines: list[str], max_new_tokens: int = 96) -> tuple[list[str], list[str]]:
    tokenizer = MarianTokenizer.from_pretrained(MODEL_NAME)
    hf_model = MarianMTModel.from_pretrained(MODEL_NAME).eval()
    scratch = build_scratch_model(hf_model, tokenizer)

    outputs, hf_outputs = [], []
    for line in lines:
        verse_no, text = split_verse(line)
        batch = tokenizer([text], return_tensors="pt", truncation=True)
        ids = greedy_decode(
            scratch,
            batch["input_ids"],
            decoder_start_token_id=hf_model.config.decoder_start_token_id,
            eos_token_id=tokenizer.eos_token_id,
            max_new_tokens=max_new_tokens,
            bad_token_ids=[tokenizer.pad_token_id],
        )
        hf_ids = hf_model.generate(**batch, do_sample=False, num_beams=1, max_new_tokens=max_new_tokens)
        prefix = f"{verse_no}. " if verse_no else ""
        outputs.append(prefix + tokenizer.decode(ids[0], skip_special_tokens=True))
        hf_outputs.append(prefix + tokenizer.decode(hf_ids[0], skip_special_tokens=True))
    return outputs, hf_outputs


def write_comparison(spanish: list[str], ours: list[str], hf: list[str], reference: list[str]) -> None:
    rows = ["| Verse | Scratch Marian weights | KJV reference | HF Marian greedy |", "|---|---|---|---|"]
    for i in range(min(8, len(ours), len(reference), len(hf))):
        verse_no, _ = split_verse(spanish[i])
        _, ours_text = split_verse(ours[i])
        _, hf_text = split_verse(hf[i])
        _, ref_text = split_verse(reference[i])
        rows.append(f"| {verse_no} | {ours_text} | {ref_text} | {hf_text} |")
    (OUT / "comparison_table.md").write_text("\n".join(rows) + "\n", encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    es_path = DATA / "genesis1_es.txt"
    ref_path = DATA / "genesis1_en_reference.txt"
    if not es_path.exists() or not ref_path.exists():
        raise SystemExit("Run `python part1_transformer/fetch_data.py` first.")
    spanish = es_path.read_text(encoding="utf-8").splitlines()
    reference = ref_path.read_text(encoding="utf-8").splitlines()
    ours, hf = translate_lines(spanish)
    (OUT / "genesis1_en_translated.txt").write_text("\n".join(ours) + "\n", encoding="utf-8")
    (OUT / "genesis1_en_hf_greedy.txt").write_text("\n".join(hf) + "\n", encoding="utf-8")
    write_comparison(spanish, ours, hf, reference)
    print(f"Wrote {len(ours)} translated verses to {OUT / 'genesis1_en_translated.txt'}")


if __name__ == "__main__":
    main()
