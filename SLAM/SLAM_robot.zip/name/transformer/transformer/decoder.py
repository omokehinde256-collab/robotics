from typing import Optional, Tuple

import torch
from torch import nn

from .attention import MultiHeadAttention
from .embeddings import Embeddings, PositionalEncoding
from .feedforward import PositionwiseFeedForward


class DecoderLayer(nn.Module):
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        d_ff: int,
        dropout: float = 0.0,
        activation: str = "gelu",
    ):
        super().__init__()
        self.self_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.self_attn_layer_norm = nn.LayerNorm(d_model)
        self.encoder_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.encoder_attn_layer_norm = nn.LayerNorm(d_model)
        self.ffn = PositionwiseFeedForward(d_model, d_ff, dropout, activation=activation)
        self.final_layer_norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        encoder_hidden: torch.Tensor,
        tgt_mask: Optional[torch.Tensor] = None,
        memory_mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # x: [batch, tgt_len, d_model]
        residual = x
        self_out, self_attn = self.self_attn(x, x, x, mask=tgt_mask)
        x = self.self_attn_layer_norm(residual + self.dropout(self_out))

        residual = x
        cross_out, cross_attn = self.encoder_attn(
            query=x, key=encoder_hidden, value=encoder_hidden, mask=memory_mask
        )
        x = self.encoder_attn_layer_norm(residual + self.dropout(cross_out))

        residual = x
        ffn_out = self.ffn(x)
        x = self.final_layer_norm(residual + self.dropout(ffn_out))
        return x, self_attn, cross_attn


class Decoder(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        num_heads: int,
        d_ff: int,
        num_layers: int,
        pad_token_id: int,
        max_len: int = 512,
        dropout: float = 0.0,
        position_offset: int = 0,
        activation: str = "gelu",
    ):
        super().__init__()
        self.embed_tokens = Embeddings(vocab_size, d_model, padding_idx=pad_token_id)
        self.embed_positions = PositionalEncoding(d_model, max_len=max_len, offset=position_offset)
        self.layers = nn.ModuleList(
            [
                DecoderLayer(d_model, num_heads, d_ff, dropout, activation=activation)
                for _ in range(num_layers)
            ]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        input_ids: torch.Tensor,
        encoder_hidden: torch.Tensor,
        tgt_mask: Optional[torch.Tensor] = None,
        memory_mask: Optional[torch.Tensor] = None,
        debug_shapes: bool = False,
    ) -> Tuple[torch.Tensor, list[torch.Tensor], list[torch.Tensor]]:
        x = self.embed_tokens(input_ids)
        if debug_shapes:
            print(f"decoder token embeddings: {tuple(x.shape)}")
        x = self.embed_positions(x)
        x = self.dropout(x)
        if debug_shapes:
            print(f"decoder + positional encoding: {tuple(x.shape)}")

        self_attns, cross_attns = [], []
        for i, layer in enumerate(self.layers):
            x, self_attn, cross_attn = layer(
                x, encoder_hidden, tgt_mask=tgt_mask, memory_mask=memory_mask
            )
            self_attns.append(self_attn)
            cross_attns.append(cross_attn)
            if debug_shapes:
                print(
                    f"decoder layer {i}: hidden={tuple(x.shape)} "
                    f"self_attn={tuple(self_attn.shape)} cross_attn={tuple(cross_attn.shape)}"
                )
        return x, self_attns, cross_attns
