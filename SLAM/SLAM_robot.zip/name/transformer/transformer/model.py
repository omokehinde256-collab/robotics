from dataclasses import dataclass
from typing import Optional

import torch
from torch import nn

from .attention import make_causal_mask, make_padding_mask
from .decoder import Decoder
from .encoder import Encoder


@dataclass
class TransformerOutput:
    logits: torch.Tensor
    encoder_hidden: torch.Tensor
    encoder_attentions: list[torch.Tensor]
    decoder_self_attentions: list[torch.Tensor]
    decoder_cross_attentions: list[torch.Tensor]


class TransformerSeq2Seq(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        num_heads: int,
        d_ff: int,
        num_encoder_layers: int,
        num_decoder_layers: int,
        pad_token_id: int,
        max_len: int = 512,
        dropout: float = 0.0,
        position_offset: int = 0,
        tie_embeddings: bool = True,
        activation: str = "gelu",
    ):
        super().__init__()
        self.pad_token_id = pad_token_id
        self.encoder = Encoder(
            vocab_size,
            d_model,
            num_heads,
            d_ff,
            num_encoder_layers,
            pad_token_id,
            max_len=max_len,
            dropout=dropout,
            position_offset=position_offset,
            activation=activation,
        )
        self.decoder = Decoder(
            vocab_size,
            d_model,
            num_heads,
            d_ff,
            num_decoder_layers,
            pad_token_id,
            max_len=max_len,
            dropout=dropout,
            position_offset=position_offset,
            activation=activation,
        )
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)
        self.register_buffer("final_logits_bias", torch.zeros(1, vocab_size), persistent=True)
        if tie_embeddings:
            self.decoder.embed_tokens.embedding.weight = self.encoder.embed_tokens.embedding.weight
            self.lm_head.weight = self.encoder.embed_tokens.embedding.weight

    def forward(
        self,
        src_ids: torch.Tensor,
        tgt_ids: torch.Tensor,
        src_mask: Optional[torch.Tensor] = None,
        tgt_mask: Optional[torch.Tensor] = None,
        debug_shapes: bool = False,
    ) -> TransformerOutput:
        if src_mask is None:
            src_mask = make_padding_mask(src_ids, self.pad_token_id)
        if tgt_mask is None:
            # During Marian generation the decoder start token is the same id
            # as the pad token, so a default decoder padding mask would hide a
            # real token. Causal masking is the essential default; callers that
            # need target padding masks can pass an explicit tgt_mask.
            tgt_mask = make_causal_mask(tgt_ids.size(1), tgt_ids.device)

        encoder_hidden, enc_attns = self.encoder(src_ids, src_mask=src_mask, debug_shapes=debug_shapes)
        # memory_mask: [batch, 1, 1, src_len], broadcast to decoder query length.
        decoder_hidden, dec_self_attns, dec_cross_attns = self.decoder(
            tgt_ids,
            encoder_hidden,
            tgt_mask=tgt_mask,
            memory_mask=src_mask,
            debug_shapes=debug_shapes,
        )
        logits = self.lm_head(decoder_hidden) + self.final_logits_bias.to(decoder_hidden.dtype)
        if debug_shapes:
            print(f"lm logits: {tuple(logits.shape)}")
        return TransformerOutput(logits, encoder_hidden, enc_attns, dec_self_attns, dec_cross_attns)


@torch.no_grad()
def greedy_decode(
    model: TransformerSeq2Seq,
    src_ids: torch.Tensor,
    decoder_start_token_id: int,
    eos_token_id: int,
    max_new_tokens: int = 128,
    bad_token_ids: Optional[list[int]] = None,
) -> torch.Tensor:
    model.eval()
    generated = torch.full(
        (src_ids.size(0), 1),
        decoder_start_token_id,
        dtype=torch.long,
        device=src_ids.device,
    )
    finished = torch.zeros(src_ids.size(0), dtype=torch.bool, device=src_ids.device)
    for _ in range(max_new_tokens):
        out = model(src_ids, generated)
        next_logits = out.logits[:, -1, :].clone()
        if bad_token_ids:
            next_logits[:, bad_token_ids] = torch.finfo(next_logits.dtype).min
        next_token = next_logits.argmax(dim=-1, keepdim=True)
        next_token = torch.where(
            finished.unsqueeze(1),
            torch.full_like(next_token, eos_token_id),
            next_token,
        )
        generated = torch.cat([generated, next_token], dim=1)
        finished |= next_token.squeeze(1).eq(eos_token_id)
        if torch.all(finished):
            break
    return generated
