import math
from typing import Optional, Tuple

import torch
from torch import nn


class ScaledDotProductAttention(nn.Module):
    def __init__(self, dropout: float = 0.0):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # q: [batch, heads, query_len, head_dim]
        # k: [batch, heads, key_len, head_dim]
        # v: [batch, heads, key_len, head_dim]
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(q.size(-1))
        # scores: [batch, heads, query_len, key_len]
        if mask is not None:
            # mask is True for allowed positions, False for blocked positions.
            scores = scores.masked_fill(~mask, torch.finfo(scores.dtype).min)
        attn = torch.softmax(scores, dim=-1)
        attn = self.dropout(attn)
        context = torch.matmul(attn, v)
        # context: [batch, heads, query_len, head_dim]
        return context, attn


class MultiHeadAttention(nn.Module):
    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.0):
        super().__init__()
        if d_model % num_heads != 0:
            raise ValueError("d_model must be divisible by num_heads")
        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads

        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)
        self.attention = ScaledDotProductAttention(dropout=dropout)

    def _split_heads(self, x: torch.Tensor) -> torch.Tensor:
        batch, seq_len, _ = x.shape
        # [batch, seq_len, d_model] -> [batch, seq_len, heads, head_dim]
        x = x.view(batch, seq_len, self.num_heads, self.head_dim)
        # [batch, seq_len, heads, head_dim] -> [batch, heads, seq_len, head_dim]
        return x.transpose(1, 2)

    def _merge_heads(self, x: torch.Tensor) -> torch.Tensor:
        batch, heads, seq_len, head_dim = x.shape
        # [batch, heads, seq_len, head_dim] -> [batch, seq_len, heads, head_dim]
        x = x.transpose(1, 2).contiguous()
        # [batch, seq_len, heads, head_dim] -> [batch, seq_len, d_model]
        return x.view(batch, seq_len, heads * head_dim)

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # query/key/value: [batch, seq_len, d_model]
        q = self._split_heads(self.q_proj(query))
        k = self._split_heads(self.k_proj(key))
        v = self._split_heads(self.v_proj(value))
        # q/k/v: [batch, heads, seq_len, head_dim]
        context, attn = self.attention(q, k, v, mask=mask)
        merged = self._merge_heads(context)
        return self.out_proj(merged), attn


def make_padding_mask(input_ids: torch.Tensor, pad_token_id: int) -> torch.Tensor:
    # [batch, key_len] -> [batch, 1, 1, key_len], True where attention may look.
    return input_ids.ne(pad_token_id).unsqueeze(1).unsqueeze(2)


def make_causal_mask(seq_len: int, device: torch.device) -> torch.Tensor:
    # [1, 1, seq_len, seq_len], True on and below the diagonal.
    return torch.tril(torch.ones(seq_len, seq_len, dtype=torch.bool, device=device)).view(
        1, 1, seq_len, seq_len
    )

