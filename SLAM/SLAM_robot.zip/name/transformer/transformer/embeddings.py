import math

import torch
from torch import nn


class Embeddings(nn.Module):
    """Token lookup table scaled by sqrt(d_model), as in Vaswani et al."""

    def __init__(self, vocab_size: int, d_model: int, padding_idx: int = 0):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, d_model, padding_idx=padding_idx)
        self.d_model = d_model

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        # input_ids: [batch, seq_len]
        # output: [batch, seq_len, d_model]
        return self.embedding(input_ids) * math.sqrt(self.d_model)


class PositionalEncoding(nn.Module):
    """Sinusoidal positional encoding.

    Marian uses static sinusoidal embeddings with a small offset. The default
    offset of 0 is the original paper version; offset=2 matches Marian's
    internal position table convention when loading Helsinki-NLP/opus-mt-es-en.
    """

    def __init__(self, d_model: int, max_len: int = 512, offset: int = 0):
        super().__init__()
        self.d_model = d_model
        self.offset = offset
        self.register_buffer("pe", self._build(max_len + offset, d_model), persistent=False)

    @staticmethod
    def _build(max_len: int, d_model: int) -> torch.Tensor:
        position = torch.arange(max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float) * (-math.log(10000.0) / d_model)
        )
        pe = torch.zeros(max_len, d_model)
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe

    def ensure_length(self, needed: int, device: torch.device) -> None:
        if needed <= self.pe.size(0):
            return
        self.pe = self._build(needed, self.d_model).to(device)

    def forward(self, x: torch.Tensor, past_len: int = 0) -> torch.Tensor:
        # x: [batch, seq_len, d_model]
        seq_len = x.size(1)
        start = self.offset + past_len
        end = start + seq_len
        self.ensure_length(end, x.device)
        # pe[start:end]: [seq_len, d_model], broadcast over batch
        return x + self.pe[start:end].unsqueeze(0).to(dtype=x.dtype, device=x.device)

