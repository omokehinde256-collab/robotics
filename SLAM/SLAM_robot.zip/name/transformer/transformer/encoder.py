from typing import Optional, Tuple

import torch
from torch import nn

from .attention import MultiHeadAttention
from .embeddings import Embeddings, PositionalEncoding
from .feedforward import PositionwiseFeedForward


class EncoderLayer(nn.Module):
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        d_ff: int,
        dropout: float = 0.0,
        activation: str = "gelu",
    ):
        super().__init__()
        self.self_attn = MultiHeadAttention(d_model, num_heads, dropout)
        self.self_attn_layer_norm = nn.LayerNorm(d_model)
        self.ffn = PositionwiseFeedForward(d_model, d_ff, dropout, activation=activation)
        self.final_layer_norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self, x: torch.Tensor, src_mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # x: [batch, src_len, d_model]
        residual = x
        attn_out, attn = self.self_attn(x, x, x, mask=src_mask)
        x = self.self_attn_layer_norm(residual + self.dropout(attn_out))

        residual = x
        ffn_out = self.ffn(x)
        x = self.final_layer_norm(residual + self.dropout(ffn_out))
        return x, attn


class Encoder(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        d_model: int,
        num_heads: int,
        d_ff: int,
        num_layers: int,
        pad_token_id: int,
        max_len: int = 512,
        dropout: float = 0.0,
        position_offset: int = 0,
        activation: str = "gelu",
    ):
        super().__init__()
        self.embed_tokens = Embeddings(vocab_size, d_model, padding_idx=pad_token_id)
        self.embed_positions = PositionalEncoding(d_model, max_len=max_len, offset=position_offset)
        self.layers = nn.ModuleList(
            [
                EncoderLayer(d_model, num_heads, d_ff, dropout, activation=activation)
                for _ in range(num_layers)
            ]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        input_ids: torch.Tensor,
        src_mask: Optional[torch.Tensor] = None,
        debug_shapes: bool = False,
    ) -> Tuple[torch.Tensor, list[torch.Tensor]]:
        x = self.embed_tokens(input_ids)
        if debug_shapes:
            print(f"encoder token embeddings: {tuple(x.shape)}")
        x = self.embed_positions(x)
        x = self.dropout(x)
        if debug_shapes:
            print(f"encoder + positional encoding: {tuple(x.shape)}")

        attentions = []
        for i, layer in enumerate(self.layers):
            x, attn = layer(x, src_mask=src_mask)
            attentions.append(attn)
            if debug_shapes:
                print(f"encoder layer {i}: hidden={tuple(x.shape)} attn={tuple(attn.shape)}")
        return x, attentions
