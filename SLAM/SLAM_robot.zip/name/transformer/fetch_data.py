import json
import re
from pathlib import Path

import requests


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
USER_AGENT = "NLUClassAssignment/1.0 educational"


def fetch_rvr1909_genesis1() -> list[str]:
    url = (
        "https://es.wikisource.org/w/index.php?"
        "title=Biblia_Reina-Valera_1909/G%C3%A9nesis/1&action=raw"
    )
    response = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=30)
    response.raise_for_status()
    verses = []
    for line in response.text.splitlines():
        match = re.match(r"\{\{vers\|1\|(\d+)\}\}\s*(.+)", line.strip())
        if match:
            verse_no, text = match.groups()
            text = re.sub(r"<[^>]+>", "", text).strip()
            verses.append(f"{verse_no}. {text}")
    if len(verses) < 20:
        raise RuntimeError("Could not parse enough RVR1909 verses from Wikisource")
    return verses


def fetch_kjv_genesis1() -> list[str]:
    url = "https://bible-api.com/genesis+1?translation=kjv"
    response = requests.get(url, timeout=30)
    response.raise_for_status()
    payload = response.json()
    verses = []
    for verse in payload["verses"]:
        text = " ".join(verse["text"].split())
        verses.append(f"{verse['verse']}. {text}")
    return verses


def main() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    es = fetch_rvr1909_genesis1()
    en = fetch_kjv_genesis1()
    (DATA / "genesis1_es.txt").write_text("\n".join(es) + "\n", encoding="utf-8")
    (DATA / "genesis1_en_reference.txt").write_text("\n".join(en) + "\n", encoding="utf-8")
    (DATA / "source_metadata.json").write_text(
        json.dumps(
            {
                "spanish": "Reina-Valera 1909 Genesis 1 from Wikisource raw page",
                "english_reference": "KJV Genesis 1 from bible-api.com",
                "note": "Reference is for sanity checking only; no training uses it.",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"Wrote {len(es)} Spanish verses and {len(en)} English reference verses.")


if __name__ == "__main__":
    main()
