from transformer.model import TransformerSeq2Seq

import torch


def main() -> None:
    model = TransformerSeq2Seq(
        vocab_size=64,
        d_model=32,
        num_heads=4,
        d_ff=64,
        num_encoder_layers=2,
        num_decoder_layers=2,
        pad_token_id=0,
        max_len=32,
        dropout=0.0,
    )
    src = torch.tensor([[5, 7, 9, 2, 0], [4, 3, 2, 0, 0]])
    tgt = torch.tensor([[1, 8, 6, 2], [1, 5, 2, 0]])
    model(src, tgt, debug_shapes=True)


if __name__ == "__main__":
    main()

